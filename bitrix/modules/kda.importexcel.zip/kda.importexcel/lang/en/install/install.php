<?php
$MESS ['KDA_IMPORTEXCEL_MODULE_NAME'] = 'Import from Excel';
$MESS ['KDA_IMPORTEXCEL_MODULE_DESCRIPTION'] = 'Download information block elements of the Excel-file';
$MESS ['KDA_PARTNER_NAME'] = 'kabubu.org';
?>