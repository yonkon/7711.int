<?
$MESS['KDA_IE_NO_PROFILE'] = "- not selected -";
$MESS['KDA_IE_NEW_PROFILE'] = "Create new";
$MESS['KDA_IE_PROFILE_NAME_EXISTS'] = "Profile with the specified name already exists";
$MESS['KDA_IE_NOT_SET_PROFILE_NAME'] = "Do not set the name of the new profile";
?>