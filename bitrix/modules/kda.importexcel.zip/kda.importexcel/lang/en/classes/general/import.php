<?
$MESS['KDA_IE_NOT_SET_UID'] = "Not Specified field to identify the item (sheet %s, field %s)";
$MESS['KDA_IE_NOT_SET_FIELD'] = "Not Specified field %s (sheet %s, line %s)";
$MESS['KDA_IE_ADD_ELEMENT_ERROR'] = "Error creating element: %s (sheet %s, line %s)";
$MESS['KDA_IE_ADD_OFFER_ERROR'] = "Error creating offer: %s (sheet %s, line %s)";
$MESS['KDA_IE_FIELD_VAL_N'] = "0,нет,not,n";
$MESS['KDA_IE_FIELD_VAL_Y'] = "1,да,yes,y";
$MESS['KDA_IE_ADD_SECTION_ERROR'] = "Error creating section '%s': %s (sheet %s, line %s)";
?>