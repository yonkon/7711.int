<?
$MESS["KDA_IE_CRON_TITLE"] = "Cron settings";
$MESS["KDA_IE_CRON_PROFILE_TITLE"] = "Profile";
$MESS["KDA_IE_CRON_CHOOSE_PROFILE"] = "Choose profile";
$MESS["KDA_IE_CRON_NO_PROFILE"] = "- not choose -";
$MESS["KDA_IE_CRON_RUN_INTERVAL"] = "Period between launches (hours):";
$MESS["KDA_IE_CRON_OR"] = "or";
$MESS["KDA_IE_CRON_RUN_TIME"] = "Launch time:";
$MESS["KDA_IE_CRON_PHP_PATH"] = "Path to php:";
$MESS["KDA_IE_CRON_AUTO_CRON"] = "Set automatically:";
$MESS["KDA_IE_CRON_SET"] = "Add to crontab";
$MESS["KDA_IE_CRON_SET"] = "Delete from crontab";
$MESS["KDA_IE_CRON_NOT_PROFILE"] = "Profile not choose";
$MESS["KDA_IE_CRON_SAVE_SUCCESS"] = "Save success";
$MESS["KDA_IE_CRON_DESCRIPTION"] = "Settings file crontab located /bitrix/crontab/crontab.cfg";
?>