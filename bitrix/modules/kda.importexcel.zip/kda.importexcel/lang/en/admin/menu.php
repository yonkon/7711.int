<?php
$MESS['KDA_MENU_IMPORT_TITLE'] = 'Import from Excel';
?>