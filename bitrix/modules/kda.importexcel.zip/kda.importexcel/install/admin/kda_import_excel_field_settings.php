<?php
require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/kda.importexcel/admin/iblock_import_excel_field_settings.php');
?>