<?
$arModuleVersion = array(
	"VERSION" => "0.5.8",
	"VERSION_DATE" => "2015-11-24 18:54:28"
);
?>