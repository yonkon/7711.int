-- phpMyAdmin SQL Dump
-- version 4.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 01, 2015 at 03:37 PM
-- Server version: 5.5.44-cll-lve
-- PHP Version: 5.4.45

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `v_9619_shop1`
--

-- --------------------------------------------------------

--
-- Table structure for table `b_lang`
--

CREATE TABLE IF NOT EXISTS `b_lang` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DIR` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_DATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(11) DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LANGUAGE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DOC_ROOT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DOMAIN_LIMITED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SERVER_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SITE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EMAIL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CULTURE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `b_lang`
--

INSERT INTO `b_lang` (`LID`, `SORT`, `DEF`, `ACTIVE`, `NAME`, `DIR`, `FORMAT_DATE`, `FORMAT_DATETIME`, `FORMAT_NAME`, `WEEK_START`, `CHARSET`, `LANGUAGE_ID`, `DOC_ROOT`, `DOMAIN_LIMITED`, `SERVER_NAME`, `SITE_NAME`, `EMAIL`, `CULTURE_ID`) VALUES
('s1', 1, 'Y', 'Y', 'Интернет-магазин UNION', '/', NULL, NULL, NULL, NULL, NULL, 'en', '', 'N', '7711.kz', 'Компания UNION', 'union@unn.kz', 1);

-- --------------------------------------------------------

--
-- Table structure for table `b_language`
--

CREATE TABLE IF NOT EXISTS `b_language` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `DEF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `FORMAT_DATE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_DATETIME` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FORMAT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WEEK_START` int(11) DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DIRECTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CULTURE_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `b_language`
--

INSERT INTO `b_language` (`LID`, `SORT`, `DEF`, `ACTIVE`, `NAME`, `FORMAT_DATE`, `FORMAT_DATETIME`, `FORMAT_NAME`, `WEEK_START`, `CHARSET`, `DIRECTION`, `CULTURE_ID`) VALUES
('en', 2, 'N', 'N', 'English', NULL, NULL, NULL, NULL, NULL, NULL, 2),
('ru', 1, 'Y', 'Y', 'Russian', NULL, NULL, NULL, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `b_lang_domain`
--

CREATE TABLE IF NOT EXISTS `b_lang_domain` (
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `DOMAIN` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_ldap_group`
--

CREATE TABLE IF NOT EXISTS `b_ldap_group` (
  `LDAP_SERVER_ID` int(11) NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `LDAP_GROUP_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_ldap_server`
--

CREATE TABLE IF NOT EXISTS `b_ldap_server` (
`ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `CODE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SERVER` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `PORT` int(11) NOT NULL DEFAULT '389',
  `ADMIN_LOGIN` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ADMIN_PASSWORD` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `BASE_DN` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_FILTER` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_ID_ATTR` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_NAME_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GROUP_MEMBERS_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_FILTER` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `USER_ID_ATTR` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `USER_NAME_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_LAST_NAME_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_EMAIL_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_GROUP_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_GROUP_ACCESSORY` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `USER_DEPARTMENT_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `USER_MANAGER_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CONVERT_UTF8` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `SYNC_PERIOD` int(18) DEFAULT NULL,
  `FIELD_MAP` text COLLATE utf8_unicode_ci,
  `ROOT_DEPARTMENT` int(18) DEFAULT NULL,
  `DEFAULT_DEPARTMENT_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMPORT_STRUCT` char(1) COLLATE utf8_unicode_ci DEFAULT 'N',
  `STRUCT_HAVE_DEFAULT` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYNC` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYNC_ATTR` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SYNC_LAST` datetime DEFAULT NULL,
  `MAX_PAGE_SIZE` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_answer`
--

CREATE TABLE IF NOT EXISTS `b_learn_answer` (
`ID` int(11) unsigned NOT NULL,
  `QUESTION_ID` int(11) unsigned NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '10',
  `ANSWER` text COLLATE utf8_unicode_ci NOT NULL,
  `CORRECT` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `FEEDBACK` text COLLATE utf8_unicode_ci,
  `MATCH_ANSWER` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_attempt`
--

CREATE TABLE IF NOT EXISTS `b_learn_attempt` (
`ID` int(11) unsigned NOT NULL,
  `TEST_ID` int(11) NOT NULL,
  `STUDENT_ID` int(18) NOT NULL,
  `DATE_START` datetime NOT NULL,
  `DATE_END` datetime DEFAULT NULL,
  `STATUS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'B',
  `COMPLETED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SCORE` int(11) DEFAULT '0',
  `MAX_SCORE` int(11) DEFAULT '0',
  `QUESTIONS` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_certification`
--

CREATE TABLE IF NOT EXISTS `b_learn_certification` (
`ID` int(11) unsigned NOT NULL,
  `STUDENT_ID` int(18) NOT NULL,
  `COURSE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DATE_CREATE` datetime DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `FROM_ONLINE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `PUBLIC_PROFILE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SUMMARY` int(11) NOT NULL DEFAULT '0',
  `MAX_SUMMARY` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_chapter`
--

CREATE TABLE IF NOT EXISTS `b_learn_chapter` (
`ID` int(11) unsigned NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `COURSE_ID` int(11) unsigned NOT NULL,
  `CHAPTER_ID` int(11) DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `PREVIEW_PICTURE` int(18) DEFAULT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `DETAIL_TEXT` longtext COLLATE utf8_unicode_ci,
  `DETAIL_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `JOURNAL_STATUS` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_course`
--

CREATE TABLE IF NOT EXISTS `b_learn_course` (
`ID` int(11) unsigned NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'name',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `PREVIEW_PICTURE` int(18) DEFAULT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `RATING` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RATING_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SCORM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `LINKED_LESSON_ID` int(11) DEFAULT NULL,
  `JOURNAL_STATUS` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_course_site`
--

CREATE TABLE IF NOT EXISTS `b_learn_course_site` (
  `COURSE_ID` int(11) unsigned NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_exceptions_log`
--

CREATE TABLE IF NOT EXISTS `b_learn_exceptions_log` (
  `DATE_REGISTERED` datetime NOT NULL,
  `CODE` int(11) NOT NULL,
  `MESSAGE` text COLLATE utf8_unicode_ci NOT NULL,
  `FFILE` text COLLATE utf8_unicode_ci NOT NULL,
  `LINE` int(11) NOT NULL,
  `BACKTRACE` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_gradebook`
--

CREATE TABLE IF NOT EXISTS `b_learn_gradebook` (
`ID` int(11) unsigned NOT NULL,
  `STUDENT_ID` int(18) NOT NULL,
  `TEST_ID` int(11) NOT NULL,
  `RESULT` int(11) DEFAULT NULL,
  `MAX_RESULT` int(11) DEFAULT NULL,
  `ATTEMPTS` int(11) NOT NULL DEFAULT '1',
  `COMPLETED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `EXTRA_ATTEMPTS` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_groups`
--

CREATE TABLE IF NOT EXISTS `b_learn_groups` (
`ID` int(11) unsigned NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TITLE` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT ' ',
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `ACTIVE_FROM` datetime DEFAULT NULL,
  `ACTIVE_TO` datetime DEFAULT NULL,
  `COURSE_LESSON_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_groups_lesson`
--

CREATE TABLE IF NOT EXISTS `b_learn_groups_lesson` (
  `LEARNING_GROUP_ID` int(11) NOT NULL DEFAULT '0',
  `LESSON_ID` int(11) NOT NULL DEFAULT '0',
  `DELAY` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_groups_member`
--

CREATE TABLE IF NOT EXISTS `b_learn_groups_member` (
  `LEARNING_GROUP_ID` int(11) NOT NULL DEFAULT '0',
  `USER_ID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_lesson`
--

CREATE TABLE IF NOT EXISTS `b_learn_lesson` (
`ID` int(11) unsigned NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DATE_CREATE` datetime DEFAULT NULL,
  `CREATED_BY` int(18) DEFAULT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `COURSE_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `CHAPTER_ID` int(11) unsigned DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'name',
  `SORT` int(11) NOT NULL DEFAULT '500',
  `PREVIEW_PICTURE` int(18) DEFAULT NULL,
  `KEYWORDS` text COLLATE utf8_unicode_ci NOT NULL,
  `PREVIEW_TEXT` text COLLATE utf8_unicode_ci,
  `PREVIEW_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `DETAIL_PICTURE` int(18) DEFAULT NULL,
  `DETAIL_TEXT` longtext COLLATE utf8_unicode_ci,
  `DETAIL_TEXT_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `LAUNCH` text COLLATE utf8_unicode_ci,
  `CODE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `WAS_CHAPTER_ID` int(11) DEFAULT NULL,
  `WAS_PARENT_CHAPTER_ID` int(11) DEFAULT NULL,
  `WAS_PARENT_COURSE_ID` int(11) DEFAULT NULL,
  `WAS_COURSE_ID` int(11) DEFAULT NULL,
  `JOURNAL_STATUS` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_lesson_edges`
--

CREATE TABLE IF NOT EXISTS `b_learn_lesson_edges` (
  `SOURCE_NODE` int(11) NOT NULL,
  `TARGET_NODE` int(11) NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_publish_prohibition`
--

CREATE TABLE IF NOT EXISTS `b_learn_publish_prohibition` (
  `COURSE_LESSON_ID` int(10) unsigned NOT NULL,
  `PROHIBITED_LESSON_ID` int(10) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_question`
--

CREATE TABLE IF NOT EXISTS `b_learn_question` (
`ID` int(11) unsigned NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LESSON_ID` int(11) unsigned NOT NULL,
  `QUESTION_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'S',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `COMMENT_TEXT` text COLLATE utf8_unicode_ci,
  `FILE_ID` int(18) DEFAULT NULL,
  `SELF` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `POINT` int(11) NOT NULL DEFAULT '10',
  `DIRECTION` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'V',
  `CORRECT_REQUIRED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `EMAIL_ANSWER` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `INCORRECT_MESSAGE` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_rights`
--

CREATE TABLE IF NOT EXISTS `b_learn_rights` (
  `LESSON_ID` int(10) unsigned NOT NULL,
  `SUBJECT_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `TASK_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_rights_all`
--

CREATE TABLE IF NOT EXISTS `b_learn_rights_all` (
  `SUBJECT_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `TASK_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `b_learn_rights_all`
--

INSERT INTO `b_learn_rights_all` (`SUBJECT_ID`, `TASK_ID`) VALUES
('CR', 60),
('G1', 61),
('G2', 53);

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_site_path`
--

CREATE TABLE IF NOT EXISTS `b_learn_site_path` (
`ID` int(11) NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `PATH` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `b_learn_site_path`
--

INSERT INTO `b_learn_site_path` (`ID`, `SITE_ID`, `PATH`, `TYPE`) VALUES
(1, 's1', '/learning/course/index.php?COURSE_ID=#COURSE_ID#&INDEX=Y', 'C'),
(2, 's1', '/learning/course/index.php?COURSE_ID=#COURSE_ID#&CHAPTER_ID=#CHAPTER_ID#', 'H'),
(3, 's1', '/learning/course/index.php?COURSE_ID=#COURSE_ID#&LESSON_ID=#LESSON_ID#', 'L'),
(4, 's1', '/learning/course/index.php?LESSON_PATH=#LESSON_PATH#', 'U');

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_student`
--

CREATE TABLE IF NOT EXISTS `b_learn_student` (
  `USER_ID` int(18) NOT NULL,
  `TRANSCRIPT` int(11) NOT NULL,
  `PUBLIC_PROFILE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `RESUME` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `b_learn_student`
--

INSERT INTO `b_learn_student` (`USER_ID`, `TRANSCRIPT`, `PUBLIC_PROFILE`, `RESUME`) VALUES
(2, 87168187, 'N', ''),
(22, 33286899, 'N', ''),
(29, 57252591, 'N', '');

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_test`
--

CREATE TABLE IF NOT EXISTS `b_learn_test` (
`ID` int(11) NOT NULL,
  `COURSE_ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SORT` int(11) NOT NULL DEFAULT '500',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DESCRIPTION_TYPE` char(4) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `ATTEMPT_LIMIT` int(11) NOT NULL DEFAULT '0',
  `TIME_LIMIT` int(11) DEFAULT '0',
  `COMPLETED_SCORE` int(11) DEFAULT NULL,
  `QUESTIONS_FROM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'A',
  `QUESTIONS_FROM_ID` int(11) NOT NULL DEFAULT '0',
  `QUESTIONS_AMOUNT` int(11) NOT NULL DEFAULT '0',
  `RANDOM_QUESTIONS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `RANDOM_ANSWERS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `APPROVED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `INCLUDE_SELF_TEST` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `PASSAGE_TYPE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `PREVIOUS_TEST_ID` int(11) DEFAULT NULL,
  `PREVIOUS_TEST_SCORE` int(11) DEFAULT '0',
  `INCORRECT_CONTROL` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `CURRENT_INDICATION` int(11) NOT NULL DEFAULT '0',
  `FINAL_INDICATION` int(11) NOT NULL DEFAULT '0',
  `MIN_TIME_BETWEEN_ATTEMPTS` int(11) NOT NULL DEFAULT '0',
  `SHOW_ERRORS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `NEXT_QUESTION_ON_ERROR` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_test_mark`
--

CREATE TABLE IF NOT EXISTS `b_learn_test_mark` (
`ID` int(11) NOT NULL,
  `TEST_ID` int(11) NOT NULL,
  `SCORE` int(11) NOT NULL,
  `MARK` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_learn_test_result`
--

CREATE TABLE IF NOT EXISTS `b_learn_test_result` (
`ID` int(11) unsigned NOT NULL,
  `ATTEMPT_ID` int(11) unsigned NOT NULL,
  `QUESTION_ID` int(11) NOT NULL,
  `RESPONSE` text COLLATE utf8_unicode_ci,
  `POINT` int(11) NOT NULL DEFAULT '0',
  `CORRECT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ANSWERED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_lists_field`
--

CREATE TABLE IF NOT EXISTS `b_lists_field` (
  `IBLOCK_ID` int(11) NOT NULL,
  `FIELD_ID` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SORT` int(11) NOT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `SETTINGS` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_lists_permission`
--

CREATE TABLE IF NOT EXISTS `b_lists_permission` (
  `IBLOCK_TYPE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_lists_socnet_group`
--

CREATE TABLE IF NOT EXISTS `b_lists_socnet_group` (
  `IBLOCK_ID` int(11) NOT NULL,
  `SOCNET_ROLE` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PERMISSION` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_lists_url`
--

CREATE TABLE IF NOT EXISTS `b_lists_url` (
  `IBLOCK_ID` int(11) NOT NULL,
  `URL` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_list_rubric`
--

CREATE TABLE IF NOT EXISTS `b_list_rubric` (
`ID` int(11) NOT NULL,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `CODE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(11) NOT NULL DEFAULT '100',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `AUTO` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DAYS_OF_MONTH` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DAYS_OF_WEEK` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TIMES_OF_DAY` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TEMPLATE` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LAST_EXECUTED` datetime DEFAULT NULL,
  `VISIBLE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `FROM_FIELD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `b_list_rubric`
--

INSERT INTO `b_list_rubric` (`ID`, `LID`, `CODE`, `NAME`, `DESCRIPTION`, `SORT`, `ACTIVE`, `AUTO`, `DAYS_OF_MONTH`, `DAYS_OF_WEEK`, `TIMES_OF_DAY`, `TEMPLATE`, `LAST_EXECUTED`, `VISIBLE`, `FROM_FIELD`) VALUES
(1, 's1', NULL, 'Новости магазина', 'Ежедневная рассылка новостей магазина.', 100, 'Y', 'Y', '', '1,2,3,4,5,6,7', '05:00', 'bitrix/php_interface/subscribe/templates/store_news_s1', '2015-04-24 05:00:00', 'Y', 'aliakbarov_nariman@mail.ru');

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_filter`
--

CREATE TABLE IF NOT EXISTS `b_mail_filter` (
`ID` int(18) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `MAILBOX_ID` int(18) NOT NULL,
  `PARENT_FILTER_ID` int(18) DEFAULT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `SORT` int(18) NOT NULL DEFAULT '500',
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `PHP_CONDITION` text COLLATE utf8_unicode_ci,
  `WHEN_MAIL_RECEIVED` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `WHEN_MANUALLY_RUN` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SPAM_RATING` decimal(9,4) DEFAULT NULL,
  `SPAM_RATING_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT '<',
  `MESSAGE_SIZE` int(18) DEFAULT NULL,
  `MESSAGE_SIZE_TYPE` char(1) COLLATE utf8_unicode_ci DEFAULT '<',
  `MESSAGE_SIZE_UNIT` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTION_STOP_EXEC` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTION_DELETE_MESSAGE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `ACTION_READ` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-',
  `ACTION_PHP` text COLLATE utf8_unicode_ci,
  `ACTION_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ACTION_VARS` text COLLATE utf8_unicode_ci,
  `ACTION_SPAM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_filter_cond`
--

CREATE TABLE IF NOT EXISTS `b_mail_filter_cond` (
`ID` int(11) NOT NULL,
  `FILTER_ID` int(11) NOT NULL,
  `TYPE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `STRINGS` text COLLATE utf8_unicode_ci NOT NULL,
  `COMPARE_TYPE` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'CONTAIN'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_log`
--

CREATE TABLE IF NOT EXISTS `b_mail_log` (
`ID` int(18) NOT NULL,
  `MAILBOX_ID` int(18) NOT NULL DEFAULT '0',
  `FILTER_ID` int(18) DEFAULT NULL,
  `MESSAGE_ID` int(18) DEFAULT NULL,
  `LOG_TYPE` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DATE_INSERT` datetime NOT NULL,
  `STATUS_GOOD` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `MESSAGE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_mailbox`
--

CREATE TABLE IF NOT EXISTS `b_mail_mailbox` (
`ID` int(18) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LID` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SERVICE_ID` int(11) NOT NULL DEFAULT '0',
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SERVER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PORT` int(18) NOT NULL DEFAULT '110',
  `LINK` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LOGIN` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CHARSET` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PASSWORD` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `USE_MD5` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DELETE_MESSAGES` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `PERIOD_CHECK` int(15) DEFAULT NULL,
  `MAX_MSG_COUNT` int(11) DEFAULT '0',
  `MAX_MSG_SIZE` int(11) DEFAULT '0',
  `MAX_KEEP_DAYS` int(11) DEFAULT '0',
  `USE_TLS` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `SERVER_TYPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'pop3',
  `DOMAINS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RELAY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `AUTH_RELAY` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `USER_ID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `b_mail_mailbox`
--

INSERT INTO `b_mail_mailbox` (`ID`, `TIMESTAMP_X`, `LID`, `ACTIVE`, `SERVICE_ID`, `NAME`, `SERVER`, `PORT`, `LINK`, `LOGIN`, `CHARSET`, `PASSWORD`, `DESCRIPTION`, `USE_MD5`, `DELETE_MESSAGES`, `PERIOD_CHECK`, `MAX_MSG_COUNT`, `MAX_MSG_SIZE`, `MAX_KEEP_DAYS`, `USE_TLS`, `SERVER_TYPE`, `DOMAINS`, `RELAY`, `AUTH_RELAY`, `USER_ID`) VALUES
(1, '2015-05-06 07:54:02', 's1', 'Y', 9, 'mail.ru', 'imap.mail.ru', 993, 'http://e.mail.ru/', 'aliakbarov_nariman@mail.ru', NULL, '4yq+6bk543WY', NULL, 'N', 'N', 0, 0, 0, 0, 'Y', 'imap', '', 'N', 'N', 1);

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_mailservices`
--

CREATE TABLE IF NOT EXISTS `b_mail_mailservices` (
`ID` int(11) NOT NULL,
  `SITE_ID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `SERVICE_TYPE` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'imap',
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SERVER` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PORT` int(11) DEFAULT NULL,
  `ENCRYPTION` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LINK` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ICON` int(11) DEFAULT NULL,
  `TOKEN` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FLAGS` int(11) NOT NULL DEFAULT '0',
  `SORT` int(11) NOT NULL DEFAULT '100'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `b_mail_mailservices`
--

INSERT INTO `b_mail_mailservices` (`ID`, `SITE_ID`, `ACTIVE`, `SERVICE_TYPE`, `NAME`, `SERVER`, `PORT`, `ENCRYPTION`, `LINK`, `ICON`, `TOKEN`, `FLAGS`, `SORT`) VALUES
(1, 's1', 'Y', 'imap', 'gmail', 'imap.gmail.com', 993, 'Y', 'https://mail.google.com/', NULL, NULL, 0, 100),
(2, 's1', 'Y', 'imap', 'outlook.com', 'imap-mail.outlook.com', 993, 'Y', 'https://www.outlook.com/owa', NULL, NULL, 0, 200),
(3, 's1', 'Y', 'imap', 'icloud', 'imap.mail.me.com', 993, 'Y', 'https://www.icloud.com/#mail', NULL, NULL, 0, 300),
(4, 's1', 'Y', 'imap', 'office365', 'outlook.office365.com', 993, 'Y', 'http://mail.office365.com/', NULL, NULL, 0, 400),
(5, 's1', 'Y', 'imap', 'exchange', NULL, NULL, NULL, NULL, NULL, NULL, 0, 500),
(6, 's1', 'Y', 'imap', 'yahoo', 'imap.mail.yahoo.com', 993, 'Y', 'http://mail.yahoo.com/', NULL, NULL, 0, 600),
(7, 's1', 'Y', 'imap', 'aol', 'imap.aol.com', 993, 'Y', 'http://mail.aol.com/', NULL, NULL, 0, 700),
(8, 's1', 'Y', 'imap', 'yandex', 'imap.yandex.ru', 993, 'Y', 'https://mail.yandex.ru/', NULL, NULL, 0, 800),
(9, 's1', 'Y', 'imap', 'mail.ru', 'imap.mail.ru', 993, 'Y', 'http://e.mail.ru/', NULL, NULL, 0, 900),
(10, 's1', 'Y', 'imap', 'ukr.net', 'imap.ukr.net', 993, 'Y', 'http://freemail.ukr.net/', NULL, NULL, 0, 1000),
(11, 's1', 'Y', 'imap', 'other', NULL, NULL, NULL, NULL, NULL, NULL, 0, 1100);

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_message`
--

CREATE TABLE IF NOT EXISTS `b_mail_message` (
`ID` int(18) NOT NULL,
  `MAILBOX_ID` int(18) NOT NULL,
  `DATE_INSERT` datetime NOT NULL,
  `FULL_TEXT` longtext COLLATE utf8_unicode_ci,
  `MESSAGE_SIZE` int(18) NOT NULL,
  `HEADER` text COLLATE utf8_unicode_ci,
  `FIELD_DATE` datetime DEFAULT NULL,
  `FIELD_FROM` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_REPLY_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_CC` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_BCC` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FIELD_PRIORITY` int(18) NOT NULL DEFAULT '3',
  `SUBJECT` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BODY` longtext COLLATE utf8_unicode_ci,
  `ATTACHMENTS` int(18) DEFAULT '0',
  `NEW_MESSAGE` char(1) COLLATE utf8_unicode_ci DEFAULT 'Y',
  `SPAM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '?',
  `SPAM_RATING` decimal(18,4) DEFAULT NULL,
  `SPAM_WORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SPAM_LAST_RESULT` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `FOR_SPAM_TEST` mediumtext COLLATE utf8_unicode_ci,
  `EXTERNAL_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MSG_ID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IN_REPLY_TO` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_message_uid`
--

CREATE TABLE IF NOT EXISTS `b_mail_message_uid` (
  `ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `MAILBOX_ID` int(18) NOT NULL,
  `SESSION_ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `DATE_INSERT` datetime NOT NULL,
  `MESSAGE_ID` int(18) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_msg_attachment`
--

CREATE TABLE IF NOT EXISTS `b_mail_msg_attachment` (
`ID` int(18) NOT NULL,
  `MESSAGE_ID` int(18) NOT NULL,
  `FILE_ID` int(18) NOT NULL DEFAULT '0',
  `FILE_NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FILE_SIZE` int(11) NOT NULL DEFAULT '0',
  `FILE_DATA` longblob,
  `CONTENT_TYPE` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IMAGE_WIDTH` int(18) DEFAULT NULL,
  `IMAGE_HEIGHT` int(18) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `b_mail_spam_weight`
--

CREATE TABLE IF NOT EXISTS `b_mail_spam_weight` (
  `WORD_ID` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `WORD_REAL` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `GOOD_CNT` int(18) NOT NULL DEFAULT '0',
  `BAD_CNT` int(18) NOT NULL DEFAULT '0',
  `TOTAL_CNT` int(18) NOT NULL DEFAULT '0',
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_medialib_collection`
--

CREATE TABLE IF NOT EXISTS `b_medialib_collection` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `ACTIVE` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `DATE_UPDATE` datetime NOT NULL,
  `OWNER_ID` int(11) DEFAULT NULL,
  `PARENT_ID` int(11) DEFAULT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ITEMS_COUNT` int(11) DEFAULT NULL,
  `ML_TYPE` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `b_medialib_collection`
--

INSERT INTO `b_medialib_collection` (`ID`, `NAME`, `DESCRIPTION`, `ACTIVE`, `DATE_UPDATE`, `OWNER_ID`, `PARENT_ID`, `SITE_ID`, `KEYWORDS`, `ITEMS_COUNT`, `ML_TYPE`) VALUES
(1, 'katalog', '', 'Y', '2015-04-28 20:20:39', 1, 0, NULL, '', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `b_medialib_collection_item`
--

CREATE TABLE IF NOT EXISTS `b_medialib_collection_item` (
  `COLLECTION_ID` int(11) NOT NULL,
  `ITEM_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `b_medialib_collection_item`
--

INSERT INTO `b_medialib_collection_item` (`COLLECTION_ID`, `ITEM_ID`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(1, 16),
(1, 17),
(1, 18),
(1, 19),
(1, 20),
(1, 21),
(1, 22),
(1, 23),
(1, 24),
(1, 25),
(1, 26),
(1, 27),
(1, 28);

-- --------------------------------------------------------

--
-- Table structure for table `b_medialib_item`
--

CREATE TABLE IF NOT EXISTS `b_medialib_item` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ITEM_TYPE` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci,
  `DATE_CREATE` datetime NOT NULL,
  `DATE_UPDATE` datetime NOT NULL,
  `SOURCE_ID` int(11) NOT NULL,
  `KEYWORDS` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SEARCHABLE_CONTENT` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `b_medialib_item`
--

INSERT INTO `b_medialib_item` (`ID`, `NAME`, `ITEM_TYPE`, `DESCRIPTION`, `DATE_CREATE`, `DATE_UPDATE`, `SOURCE_ID`, `KEYWORDS`, `SEARCHABLE_CONTENT`) VALUES
(1, '75d9b4539935ee88b4194fd7f6c99ec3.png', '', '', '2015-04-28 20:20:47', '2015-04-28 20:20:47', 1594, '', '{75D9B4539935EE88B4194FD7F6C99EC3}{PNG}'),
(2, 'Seidon_200_250.jpg', '', '', '2015-04-29 10:37:35', '2015-04-29 10:37:35', 1595, '', '{SEIDON}{200}{250}{JPG}'),
(3, 'logo_union5.jpg', '', '', '2015-04-30 16:58:22', '2015-04-30 16:58:22', 1632, '', '{LOGO}{UNION5}{JPG}'),
(4, 'logo.png', '', '', '2015-04-30 17:32:59', '2015-04-30 17:32:59', 1637, '', '{LOGO}{PNG}'),
(5, '4942d983a7baaa5e8284eb5faada3fc3.png', '', '', '2015-05-04 11:15:23', '2015-05-04 11:15:23', 1661, '', '{4942D983A7BAAA5E8284EB5FAADA3FC3}{PNG}'),
(6, '522eb4143038328805b540552c15b041.png', '', '', '2015-05-04 11:17:18', '2015-05-04 11:17:18', 1662, 'Комплектующие для компьютеров', '{522EB4143038328805B540552C15B041}{PNG}{КОМПЛЕКТ}{КОМПЬЮТЕРОВ}{КОМПЬЮТЕР}'),
(7, 'd27eb610d68bac198d818ca3748c5014.png', '', '', '2015-05-04 11:17:55', '2015-05-04 11:17:55', 1663, '', '{D27EB610D68BAC198D818CA3748C5014}{PNG}'),
(8, '544dab0ed4f210c1cf361797809ac723.png', '', '', '2015-05-04 11:18:44', '2015-05-04 11:18:44', 1664, '', '{544DAB0ED4F210C1CF361797809AC723}{PNG}'),
(9, 'a7492af5d6de877553d9bc1aa158a6dc.png', '', '', '2015-05-04 11:19:30', '2015-05-04 11:19:30', 1665, '', '{A7492AF5D6DE877553D9BC1AA158A6DC}{PNG}'),
(10, '885e765b562a07e8c1603b1e72bbbba6.png', '', '', '2015-05-04 11:20:12', '2015-05-04 11:20:12', 1666, '', '{885E765B562A07E8C1603B1E72BBBBA6}{PNG}'),
(11, '4beac02520ec46df6889f42d104e8dae.png', '', '', '2015-05-04 11:21:05', '2015-05-04 11:21:05', 1667, '', '{4BEAC02520EC46DF6889F42D104E8DAE}{PNG}'),
(12, '82679ea9c8d5518e96fc38f00a99fb10.png', '', '', '2015-05-04 11:21:47', '2015-05-04 11:21:47', 1668, '', '{82679EA9C8D5518E96FC38F00A99FB10}{PNG}'),
(13, '83c1c5a7944a53054adfd0592dd108a8.png', '', '', '2015-05-04 11:22:35', '2015-05-04 11:22:35', 1669, '', '{83C1C5A7944A53054ADFD0592DD108A8}{PNG}'),
(14, '1cc9d9a458715041a5643df07c5159e8.png', '', '', '2015-05-04 11:23:17', '2015-05-04 11:23:17', 1670, '', '{1CC9D9A458715041A5643DF07C5159E8}{PNG}'),
(15, '1160226d9aba60e3ed87723ff5115df7.png', '', '', '2015-05-04 11:23:59', '2015-05-04 11:23:59', 1671, '', '{1160226D9ABA60E3ED87723FF5115DF7}{PNG}'),
(16, '66acf860a432d7be84b1b581d503d6f6.png', '', '', '2015-05-04 11:25:11', '2015-05-04 11:25:11', 1672, '', '{66ACF860A432D7BE84B1B581D503D6F6}{PNG}'),
(17, '75c7dee0485d3c7739778b12f95b34dd.png', '', '', '2015-05-04 11:25:58', '2015-05-04 11:25:58', 1673, '', '{75C7DEE0485D3C7739778B12F95B34DD}{PNG}'),
(18, 'c851a75381af07a7200d393ab8426643.png', '', '', '2015-05-04 11:26:48', '2015-05-04 11:26:48', 1674, '', '{C851A75381AF07A7200D393AB8426643}{PNG}'),
(19, '7a115c9b199d5a86edf17f0464228dd3.png', '', '', '2015-05-04 11:27:28', '2015-05-04 11:27:28', 1675, '', '{7A115C9B199D5A86EDF17F0464228DD3}{PNG}'),
(20, '098a5a0de002260741e2cf4c196c04e0.png', '', '', '2015-05-04 11:28:13', '2015-05-04 11:28:13', 1676, '', '{098A5A0DE002260741E2CF4C196C04E0}{PNG}'),
(21, '50004ca545b59744b845d486bc004302.png', '', '', '2015-05-04 11:29:43', '2015-05-04 11:29:43', 1677, '', '{50004CA545B59744B845D486BC004302}{PNG}'),
(22, 'uslugi.png', '', '', '2015-05-04 11:30:43', '2015-05-04 11:30:43', 1678, '', '{USLUGI}{PNG}'),
(23, 'upmenu.png', '', '', '2015-05-15 18:38:33', '2015-05-15 18:38:33', 1688, '', '{UPMENU}{PNG}'),
(24, 'vk.jpg', '', '', '2015-06-09 15:43:05', '2015-06-09 15:43:05', 6711, '', '{VK}{JPG}'),
(25, 'fb.jpg', '', '', '2015-06-09 15:43:21', '2015-06-09 15:43:21', 6712, '', '{FB}{JPG}'),
(26, 'twitter.jpg', '', '', '2015-06-09 15:43:34', '2015-06-09 15:43:34', 6713, '', '{TWITTER}{JPG}'),
(27, 'g_plus.jpg', '', '', '2015-06-09 15:43:48', '2015-06-09 15:43:48', 6714, '', '{PLUS}{JPG}'),
(28, 'insta.png', '', '', '2015-06-09 17:31:15', '2015-06-09 17:31:15', 6715, '', '{INSTA}{PNG}');

-- --------------------------------------------------------

--
-- Table structure for table `b_medialib_type`
--

CREATE TABLE IF NOT EXISTS `b_medialib_type` (
`ID` int(11) NOT NULL,
  `NAME` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CODE` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `EXT` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SYSTEM` char(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'N',
  `DESCRIPTION` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `b_medialib_type`
--

INSERT INTO `b_medialib_type` (`ID`, `NAME`, `CODE`, `EXT`, `SYSTEM`, `DESCRIPTION`) VALUES
(1, 'image_name', 'image', 'jpg,jpeg,gif,png', 'Y', 'image_desc'),
(2, 'video_name', 'video', 'flv,mp4,wmv', 'Y', 'video_desc'),
(3, 'sound_name', 'sound', 'mp3,wma,aac', 'Y', 'sound_desc');

-- --------------------------------------------------------

--
-- Table structure for table `b_mobileapp_app`
--

CREATE TABLE IF NOT EXISTS `b_mobileapp_app` (
  `CODE` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `SHORT_NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NAME` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DESCRIPTION` text COLLATE utf8_unicode_ci NOT NULL,
  `FILES` text COLLATE utf8_unicode_ci NOT NULL,
  `FOLDER` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL,
  `LAUNCH_ICONS` text COLLATE utf8_unicode_ci NOT NULL,
  `LAUNCH_SCREENS` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_mobileapp_config`
--

CREATE TABLE IF NOT EXISTS `b_mobileapp_config` (
  `APP_CODE` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `PLATFORM` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `PARAMS` text COLLATE utf8_unicode_ci NOT NULL,
  `DATE_CREATE` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `b_module`
--

CREATE TABLE IF NOT EXISTS `b_module` (
  `ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DATE_ACTIVE` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `b_module`
--

INSERT INTO `b_module` (`ID`, `DATE_ACTIVE`) VALUES
('advertising', '2015-04-14 06:28:56'),
('bitrix.eshop', '2015-04-14 06:28:58'),
('bitrix.sitecommunity', '2015-04-14 06:28:58'),
('bitrix.sitecorporate', '2015-04-14 06:28:59'),
('bitrix.siteinfoportal', '2015-04-14 06:29:00'),
('bitrix.sitepersonal', '2015-04-14 06:29:01'),
('bitrixcloud', '2015-04-14 06:29:01'),
('bizproc', '2015-04-14 06:29:02'),
('bizprocdesigner', '2015-04-14 06:29:04'),
('blog', '2015-04-14 06:29:07'),
('calendar', '2015-04-14 06:29:13'),
('catalog', '2015-04-14 06:29:15'),
('clouds', '2015-04-14 06:29:17'),
('cluster', '2015-04-14 06:29:18'),
('compression', '2015-04-14 06:29:19'),
('currency', '2015-04-14 06:29:19'),
('eshopapp', '2015-04-14 06:49:30'),
('fileman', '2015-04-14 06:29:21'),
('form', '2015-04-14 06:29:24'),
('forum', '2015-04-14 06:29:26'),
('highloadblock', '2015-04-14 06:29:32'),
('iblock', '2015-04-14 06:29:34'),
('idea', '2015-04-14 06:29:40'),
('im', '2015-04-14 06:29:42'),
('itlogic.messages', '2015-05-23 05:48:28'),
('jivosite.jivosite', '2015-06-09 10:55:19'),
('ldap', '2015-04-14 06:29:43'),
('learning', '2015-04-14 06:29:44'),
('lists', '2015-04-14 06:29:46'),
('mail', '2015-04-14 06:29:48'),
('main', '2015-04-14 06:28:46'),
('mcart.list', '2015-05-25 05:47:16'),
('mcart.xls', '2015-04-23 07:21:09'),
('mobileapp', '2015-04-14 06:29:49'),
('omg.import', '2015-04-23 07:18:17'),
('perfmon', '2015-04-14 06:29:52'),
('photogallery', '2015-04-14 06:29:52'),
('phpsolutions.backtotop', '2015-06-18 04:47:11'),
('pull', '2015-04-14 06:29:55'),
('report', '2015-04-14 06:29:56'),
('sale', '2015-04-14 06:30:00'),
('scale', '2015-04-14 06:30:06'),
('search', '2015-04-14 06:30:07'),
('security', '2015-04-14 06:30:09'),
('seo', '2015-04-14 06:30:10'),
('socialnetwork', '2015-04-14 06:30:13'),
('socialservices', '2015-04-14 06:30:22'),
('softeffect.xls', '2015-05-27 09:56:39'),
('statistic', '2015-04-14 06:30:25'),
('storeassist', '2015-04-14 06:30:32'),
('subscribe', '2015-04-14 06:30:33'),
('support', '2015-04-14 06:30:35'),
('translate', '2015-04-14 06:30:36'),
('vampirus.kkb', '2015-06-05 10:57:28'),
('vote', '2015-04-14 06:30:37'),
('webservice', '2015-04-14 06:30:39'),
('wiki', '2015-04-14 06:30:40'),
('workflow', '2015-04-14 06:30:42');

-- --------------------------------------------------------

--
-- Table structure for table `b_module_group`
--

CREATE TABLE IF NOT EXISTS `b_module_group` (
`ID` int(11) NOT NULL,
  `MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `GROUP_ID` int(11) NOT NULL,
  `G_ACCESS` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `SITE_ID` char(2) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=95 ;

--
-- Dumping data for table `b_module_group`
--

INSERT INTO `b_module_group` (`ID`, `MODULE_ID`, `GROUP_ID`, `G_ACCESS`, `SITE_ID`) VALUES
(3, 'catalog', 6, 'T', NULL),
(4, 'main', 7, 'P', NULL),
(5, 'fileman', 7, 'F', NULL),
(20, 'main', 5, 'P', NULL),
(24, 'main', 6, 'Q', NULL),
(35, 'catalog', 8, 'R', NULL),
(36, 'clouds', 8, 'D', NULL),
(40, 'fileman', 8, 'D', NULL),
(50, 'security', 8, 'D', NULL),
(51, 'seo', 8, 'D', NULL),
(62, 'advertising', 8, 'D', NULL),
(63, 'bitrix.siteinfoportal', 8, 'D', NULL),
(64, 'bizproc', 8, 'D', NULL),
(65, 'bizprocdesigner', 8, 'D', NULL),
(66, 'blog', 8, 'D', NULL),
(67, 'calendar', 8, 'D', NULL),
(68, 'cluster', 8, 'D', NULL),
(69, 'currency', 8, 'D', NULL),
(70, 'eshopapp', 8, 'D', NULL),
(71, 'form', 8, 'D', NULL),
(72, 'forum', 8, 'D', NULL),
(73, 'im', 8, 'D', NULL),
(74, 'learning', 8, 'D', NULL),
(75, 'mcart.xls', 8, 'D', NULL),
(76, 'mobileapp', 8, 'D', NULL),
(77, 'perfmon', 8, 'D', NULL),
(78, 'pull', 8, 'D', NULL),
(80, 'socialnetwork', 8, 'D', NULL),
(81, 'statistic', 8, 'D', NULL),
(82, 'storeassist', 8, 'D', NULL),
(83, 'subscribe', 8, 'D', NULL),
(84, 'support', 8, 'D', NULL),
(85, 'translate', 8, 'D', NULL),
(86, 'vampirus.kkb', 8, 'D', NULL),
(87, 'vote', 8, 'D', NULL),
(88, 'wiki', 8, 'D', NULL),
(89, 'workflow', 8, 'D', NULL),
(93, 'sale', 8, 'U', NULL),
(94, 'sale', 6, 'U', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `b_module_to_module`
--

CREATE TABLE IF NOT EXISTS `b_module_to_module` (
`ID` int(11) NOT NULL,
  `TIMESTAMP_X` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `SORT` int(18) NOT NULL DEFAULT '100',
  `FROM_MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MESSAGE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TO_MODULE_ID` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TO_PATH` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_CLASS` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_METHOD` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TO_METHOD_ARG` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VERSION` int(18) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=423 ;

--
-- Dumping data for table `b_module_to_module`
--

INSERT INTO `b_module_to_module` (`ID`, `TIMESTAMP_X`, `SORT`, `FROM_MODULE_ID`, `MESSAGE_ID`, `TO_MODULE_ID`, `TO_PATH`, `TO_CLASS`, `TO_METHOD`, `TO_METHOD_ARG`, `VERSION`) VALUES
(1, '2015-04-14 06:28:46', 100, 'iblock', 'OnIBlockPropertyBuildList', 'main', '/modules/main/tools/prop_userid.php', 'CIBlockPropertyUserID', 'GetUserTypeDescription', '', 1),
(2, '2015-04-14 06:28:46', 100, 'main', 'OnUserDelete', 'main', '/modules/main/classes/mysql/favorites.php', 'CFavorites', 'OnUserDelete', '', 1),
(3, '2015-04-14 06:28:46', 100, 'main', 'OnLanguageDelete', 'main', '/modules/main/classes/mysql/favorites.php', 'CFavorites', 'OnLanguageDelete', '', 1),
(4, '2015-04-14 06:28:46', 100, 'main', 'OnUserDelete', 'main', '', 'CUserOptions', 'OnUserDelete', '', 1),
(5, '2015-04-14 06:28:46', 100, 'main', 'OnChangeFile', 'main', '', 'CMain', 'OnChangeFileComponent', '', 1),
(6, '2015-04-14 06:28:46', 100, 'main', 'OnUserTypeRightsCheck', 'main', '', 'CUser', 'UserTypeRightsCheck', '', 1),
(7, '2015-04-14 06:28:46', 100, 'main', 'OnUserLogin', 'main', '', 'UpdateTools', 'CheckUpdates', '', 1),
(8, '2015-04-14 06:28:46', 100, 'main', 'OnModuleUpdate', 'main', '', 'UpdateTools', 'SetUpdateResult', '', 1),
(9, '2015-04-14 06:28:46', 100, 'main', 'OnUpdateCheck', 'main', '', 'UpdateTools', 'SetUpdateError', '', 1),
(10, '2015-04-14 06:28:46', 100, 'main', 'OnPanelCreate', 'main', '', 'CUndo', 'CheckNotifyMessage', '', 1),
(11, '2015-04-14 06:28:46', 100, 'main', 'OnAfterAddRating', 'main', '', 'CRatingsComponentsMain', 'OnAfterAddRating', '', 1),
(12, '2015-04-14 06:28:46', 100, 'main', 'OnAfterUpdateRating', 'main', '', 'CRatingsComponentsMain', 'OnAfterUpdateRating', '', 1),
(13, '2015-04-14 06:28:46', 100, 'main', 'OnSetRatingsConfigs', 'main', '', 'CRatingsComponentsMain', 'OnSetRatingConfigs', '', 1),
(14, '2015-04-14 06:28:46', 100, 'main', 'OnGetRatingsConfigs', 'main', '', 'CRatingsComponentsMain', 'OnGetRatingConfigs', '', 1),
(15, '2015-04-14 06:28:46', 100, 'main', 'OnGetRatingsObjects', 'main', '', 'CRatingsComponentsMain', 'OnGetRatingObject', '', 1),
(16, '2015-04-14 06:28:46', 100, 'main', 'OnGetRatingContentOwner', 'main', '', 'CRatingsComponentsMain', 'OnGetRatingContentOwner', '', 1),
(17, '2015-04-14 06:28:46', 100, 'main', 'OnAfterAddRatingRule', 'main', '', 'CRatingRulesMain', 'OnAfterAddRatingRule', '', 1),
(18, '2015-04-14 06:28:46', 100, 'main', 'OnAfterUpdateRatingRule', 'main', '', 'CRatingRulesMain', 'OnAfterUpdateRatingRule', '', 1),
(19, '2015-04-14 06:28:46', 100, 'main', 'OnGetRatingRuleObjects', 'main', '', 'CRatingRulesMain', 'OnGetRatingRuleObjects', '', 1),
(20, '2015-04-14 06:28:46', 100, 'main', 'OnGetRatingRuleConfigs', 'main', '', 'CRatingRulesMain', 'OnGetRatingRuleConfigs', '', 1),
(21, '2015-04-14 06:28:46', 100, 'main', 'OnAfterUserAdd', 'main', '', 'CRatings', 'OnAfterUserRegister', '', 1),
(22, '2015-04-14 06:28:46', 100, 'main', 'OnUserDelete', 'main', '', 'CRatings', 'OnUserDelete', '', 1),
(23, '2015-04-14 06:28:46', 100, 'main', 'OnUserDelete', 'main', '', 'CAccess', 'OnUserDelete', '', 1),
(24, '2015-04-14 06:28:46', 100, 'main', 'OnAfterGroupAdd', 'main', '', 'CGroupAuthProvider', 'OnAfterGroupAdd', '', 1),
(25, '2015-04-14 06:28:46', 100, 'main', 'OnBeforeGroupUpdate', 'main', '', 'CGroupAuthProvider', 'OnBeforeGroupUpdate', '', 1),
(26, '2015-04-14 06:28:46', 100, 'main', 'OnBeforeGroupDelete', 'main', '', 'CGroupAuthProvider', 'OnBeforeGroupDelete', '', 1),
(27, '2015-04-14 06:28:46', 100, 'main', 'OnAfterSetUserGroup', 'main', '', 'CGroupAuthProvider', 'OnAfterSetUserGroup', '', 1),
(28, '2015-04-14 06:28:46', 100, 'main', 'OnUserLogin', 'main', '', 'CGroupAuthProvider', 'OnUserLogin', '', 1),
(29, '2015-04-14 06:28:46', 100, 'main', 'OnEventLogGetAuditTypes', 'main', '', 'CEventMain', 'GetAuditTypes', '', 1),
(30, '2015-04-14 06:28:46', 100, 'main', 'OnEventLogGetAuditHandlers', 'main', '', 'CEventMain', 'MakeMainObject', '', 1),
(31, '2015-04-14 06:28:46', 100, 'perfmon', 'OnGetTableSchema', 'main', '', 'CTableSchema', 'OnGetTableSchema', '', 1),
(32, '2015-04-14 06:28:46', 110, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeString', 'GetUserTypeDescription', '', 1),
(33, '2015-04-14 06:28:46', 120, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeInteger', 'GetUserTypeDescription', '', 1),
(34, '2015-04-14 06:28:46', 130, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeDouble', 'GetUserTypeDescription', '', 1),
(35, '2015-04-14 06:28:46', 140, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeDateTime', 'GetUserTypeDescription', '', 1),
(36, '2015-04-14 06:28:46', 145, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeDate', 'GetUserTypeDescription', '', 1),
(37, '2015-04-14 06:28:46', 150, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeBoolean', 'GetUserTypeDescription', '', 1),
(38, '2015-04-14 06:28:46', 160, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeFile', 'GetUserTypeDescription', '', 1),
(39, '2015-04-14 06:28:46', 170, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeEnum', 'GetUserTypeDescription', '', 1),
(40, '2015-04-14 06:28:46', 180, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeIBlockSection', 'GetUserTypeDescription', '', 1),
(41, '2015-04-14 06:28:46', 190, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeIBlockElement', 'GetUserTypeDescription', '', 1),
(42, '2015-04-14 06:28:46', 200, 'main', 'OnUserTypeBuildList', 'main', '', 'CUserTypeStringFormatted', 'GetUserTypeDescription', '', 1),
(43, '2015-04-14 06:28:46', 100, 'main', 'OnBeforeEndBufferContent', 'main', '', '\\Bitrix\\Main\\Analytics\\Counter', 'onBeforeEndBufferContent', '', 1),
(44, '2015-04-14 06:28:46', 100, 'main', 'OnBeforeRestartBuffer', 'main', '', '\\Bitrix\\Main\\Analytics\\Counter', 'onBeforeRestartBuffer', '', 1),
(45, '2015-04-14 06:28:56', 100, 'main', 'OnBeforeProlog', 'advertising', '', '', '', '', 1),
(46, '2015-04-14 06:28:56', 100, 'main', 'OnEndBufferContent', 'advertising', '', 'CAdvBanner', 'FixShowAll', '', 1),
(47, '2015-04-14 06:28:56', 100, 'main', 'OnBeforeRestartBuffer', 'advertising', '', 'CAdvBanner', 'BeforeRestartBuffer', '', 1),
(48, '2015-04-14 06:28:58', 100, 'main', 'OnBeforeProlog', 'bitrix.eshop', '', 'CEShop', 'ShowPanel', '', 1),
(49, '2015-04-14 06:28:58', 100, 'main', 'OnBeforeProlog', 'bitrix.sitecommunity', '', 'CSiteCommunity', 'ShowPanel', '', 1),
(50, '2015-04-14 06:28:59', 100, 'main', 'OnBeforeProlog', 'bitrix.sitecorporate', '', 'CSiteCorporate', 'ShowPanel', '', 1),
(51, '2015-04-14 06:29:00', 100, 'main', 'OnBeforeProlog', 'bitrix.siteinfoportal', '', 'CSiteInfoportal', 'ShowPanel', '', 1),
(52, '2015-04-14 06:29:01', 100, 'main', 'OnBeforeProlog', 'bitrix.sitepersonal', '', 'CSitePersonal', 'ShowPanel', '', 1),
(53, '2015-04-14 06:29:01', 100, 'main', 'OnAdminInformerInsertItems', 'bitrixcloud', '', 'CBitrixCloudCDN', 'OnAdminInformerInsertItems', '', 1),
(54, '2015-04-14 06:29:01', 100, 'main', 'OnAdminInformerInsertItems', 'bitrixcloud', '', 'CBitrixCloudBackup', 'OnAdminInformerInsertItems', '', 1),
(55, '2015-04-14 06:29:01', 100, 'mobileapp', 'OnBeforeAdminMobileMenuBuild', 'bitrixcloud', '', 'CBitrixCloudMobile', 'OnBeforeAdminMobileMenuBuild', '', 1),
(56, '2015-04-14 06:29:02', 100, 'iblock', 'OnAfterIBlockElementDelete', 'bizproc', '', 'CBPVirtualDocument', 'OnAfterIBlockElementDelete', '', 1),
(57, '2015-04-14 06:29:02', 100, 'main', 'OnAdminInformerInsertItems', 'bizproc', '', 'CBPAllTaskService', 'OnAdminInformerInsertItems', '', 1),
(58, '2015-04-14 06:29:07', 100, 'search', 'OnReindex', 'blog', '', 'CBlogSearch', 'OnSearchReindex', '', 1),
(59, '2015-04-14 06:29:07', 100, 'main', 'OnUserDelete', 'blog', '', 'CBlogUser', 'Delete', '', 1),
(60, '2015-04-14 06:29:07', 100, 'main', 'OnSiteDelete', 'blog', '', 'CBlogSitePath', 'DeleteBySiteID', '', 1),
(61, '2015-04-14 06:29:07', 100, 'socialnetwork', 'OnSocNetGroupDelete', 'blog', '', 'CBlogSoNetPost', 'OnGroupDelete', '', 1),
(62, '2015-04-14 06:29:07', 100, 'socialnetwork', 'OnSocNetFeaturesAdd', 'blog', '', 'CBlogSearch', 'SetSoNetFeatureIndexSearch', '', 1),
(63, '2015-04-14 06:29:07', 100, 'socialnetwork', 'OnSocNetFeaturesUpdate', 'blog', '', 'CBlogSearch', 'SetSoNetFeatureIndexSearch', '', 1),
(64, '2015-04-14 06:29:07', 100, 'socialnetwork', 'OnSocNetFeaturesPermsAdd', 'blog', '', 'CBlogSearch', 'SetSoNetFeaturePermIndexSearch', '', 1),
(65, '2015-04-14 06:29:07', 100, 'socialnetwork', 'OnSocNetFeaturesPermsUpdate', 'blog', '', 'CBlogSearch', 'SetSoNetFeaturePermIndexSearch', '', 1),
(66, '2015-04-14 06:29:07', 200, 'main', 'OnAfterAddRating', 'blog', '', 'CRatingsComponentsBlog', 'OnAfterAddRating', '', 1),
(67, '2015-04-14 06:29:07', 200, 'main', 'OnAfterUpdateRating', 'blog', '', 'CRatingsComponentsBlog', 'OnAfterUpdateRating', '', 1),
(68, '2015-04-14 06:29:07', 200, 'main', 'OnSetRatingsConfigs', 'blog', '', 'CRatingsComponentsBlog', 'OnSetRatingConfigs', '', 1),
(69, '2015-04-14 06:29:07', 200, 'main', 'OnGetRatingsConfigs', 'blog', '', 'CRatingsComponentsBlog', 'OnGetRatingConfigs', '', 1),
(70, '2015-04-14 06:29:07', 200, 'main', 'OnGetRatingsObjects', 'blog', '', 'CRatingsComponentsBlog', 'OnGetRatingObject', '', 1),
(71, '2015-04-14 06:29:07', 200, 'main', 'OnGetRatingContentOwner', 'blog', '', 'CRatingsComponentsBlog', 'OnGetRatingContentOwner', '', 1),
(72, '2015-04-14 06:29:07', 100, 'im', 'OnGetNotifySchema', 'blog', '', 'CBlogNotifySchema', 'OnGetNotifySchema', '', 1),
(73, '2015-04-14 06:29:13', 100, 'pull', 'OnGetDependentModule', 'calendar', '', 'CCalendarPullSchema', 'OnGetDependentModule', '', 1),
(74, '2015-04-14 06:29:13', 100, 'im', 'OnGetNotifySchema', 'calendar', '', 'CCalendarNotifySchema', 'OnGetNotifySchema', '', 1),
(75, '2015-04-14 06:29:13', 100, 'im', 'OnBeforeConfirmNotify', 'calendar', '', 'CCalendar', 'HandleImCallback', '', 1),
(76, '2015-04-14 06:29:13', 100, 'intranet', 'OnPlannerInit', 'calendar', '', 'CCalendarEventHandlers', 'OnPlannerInit', '', 1),
(77, '2015-04-14 06:29:13', 100, 'intranet', 'OnPlannerAction', 'calendar', '', 'CCalendarEventHandlers', 'OnPlannerAction', '', 1),
(78, '2015-04-14 06:29:13', 100, 'rest', 'OnRestServiceBuildDescription', 'calendar', '', 'CCalendarRestService', 'OnRestServiceBuildDescription', '', 1),
(79, '2015-04-14 06:29:13', 100, 'socialnetwork', 'OnFillSocNetFeaturesList', 'calendar', '', 'CCalendarLiveFeed', 'AddEvent', '', 1),
(80, '2015-04-14 06:29:13', 100, 'socialnetwork', 'OnSonetLogEntryMenuCreate', 'calendar', '', 'CCalendarLiveFeed', 'OnSonetLogEntryMenuCreate', '', 1),
(81, '2015-04-14 06:29:13', 100, 'socialnetwork', 'OnAfterSonetLogEntryAddComment', 'calendar', '', 'CCalendarLiveFeed', 'OnAfterSonetLogEntryAddComment', '', 1),
(82, '2015-04-14 06:29:13', 100, 'socialnetwork', 'OnForumCommentIMNotify', 'calendar', '', 'CCalendarLiveFeed', 'OnForumCommentIMNotify', '', 1),
(83, '2015-04-14 06:29:13', 100, 'socialnetwork', 'onAfterCommentAddAfter', 'calendar', '', 'CCalendarLiveFeed', 'onAfterCommentAddAfter', '', 1),
(84, '2015-04-14 06:29:13', 100, 'socialnetwork', 'onAfterCommentUpdateAfter', 'calendar', '', 'CCalendarLiveFeed', 'onAfterCommentUpdateAfter', '', 1),
(85, '2015-04-14 06:29:13', 100, 'search', 'BeforeIndex', 'calendar', '', 'CCalendarLiveFeed', 'FixForumCommentURL', '', 1),
(86, '2015-04-14 06:29:15', 100, 'iblock', 'OnIBlockDelete', 'catalog', '', 'CCatalog', 'OnIBlockDelete', '', 1),
(87, '2015-04-14 06:29:15', 100, 'iblock', 'OnIBlockElementDelete', 'catalog', '', 'CCatalogProduct', 'OnIBlockElementDelete', '', 1),
(88, '2015-04-14 06:29:15', 100, 'iblock', 'OnIBlockElementDelete', 'catalog', '', 'CPrice', 'OnIBlockElementDelete', '', 1),
(89, '2015-04-14 06:29:15', 100, 'iblock', 'OnIBlockElementDelete', 'catalog', '', 'CCatalogStoreProduct', 'OnIBlockElementDelete', '', 1),
(90, '2015-04-14 06:29:15', 100, 'iblock', 'OnIBlockElementDelete', 'catalog', '', 'CCatalogDocs', 'OnIBlockElementDelete', '', 1),
(91, '2015-04-14 06:29:15', 100, 'iblock', 'OnBeforeIBlockElementDelete', 'catalog', '', 'CCatalogDocs', 'OnBeforeIBlockElementDelete', '', 1),
(92, '2015-04-14 06:29:15', 100, 'currency', 'OnCurrencyDelete', 'catalog', '', 'CPrice', 'OnCurrencyDelete', '', 1),
(93, '2015-04-14 06:29:15', 100, 'main', 'OnGroupDelete', 'catalog', '', 'CCatalogProductGroups', 'OnGroupDelete', '', 1),
(94, '2015-04-14 06:29:15', 100, 'iblock', 'OnAfterIBlockElementUpdate', 'catalog', '', 'CCatalogProduct', 'OnAfterIBlockElementUpdate', '', 1),
(95, '2015-04-14 06:29:15', 100, 'currency', 'OnModuleUnInstall', 'catalog', '', '', 'CurrencyModuleUnInstallCatalog', '', 1),
(96, '2015-04-14 06:29:15', 300, 'iblock', 'OnBeforeIBlockDelete', 'catalog', '', 'CCatalog', 'OnBeforeCatalogDelete', '', 1),
(97, '2015-04-14 06:29:15', 10000, 'iblock', 'OnBeforeIBlockElementDelete', 'catalog', '', 'CCatalog', 'OnBeforeIBlockElementDelete', '', 1),
(98, '2015-04-14 06:29:15', 100, 'main', 'OnEventLogGetAuditTypes', 'catalog', '', 'CCatalogEvent', 'GetAuditTypes', '', 1),
(101, '2015-04-14 06:29:15', 100, 'main', 'OnBuildGlobalMenu', 'catalog', '', 'CCatalogAdmin', 'OnBuildGlobalMenu', '', 1),
(102, '2015-04-14 06:29:15', 100, 'main', 'OnAdminListDisplay', 'catalog', '', 'CCatalogAdmin', 'OnAdminListDisplay', '', 1),
(103, '2015-04-14 06:29:15', 100, 'main', 'OnBuildGlobalMenu', 'catalog', '', 'CCatalogAdmin', 'OnBuildSaleMenu', '', 1),
(104, '2015-04-14 06:29:15', 100, 'catalog', 'OnCondCatControlBuildList', 'catalog', '', 'CCatalogCondCtrlGroup', 'GetControlDescr', '', 1),
(105, '2015-04-14 06:29:15', 200, 'catalog', 'OnCondCatControlBuildList', 'catalog', '', 'CCatalogCondCtrlIBlockFields', 'GetControlDescr', '', 1),
(106, '2015-04-14 06:29:15', 300, 'catalog', 'OnCondCatControlBuildList', 'catalog', '', 'CCatalogCondCtrlIBlockProps', 'GetControlDescr', '', 1),
(107, '2015-04-14 06:29:15', 100, 'catalog', 'OnDocumentBarcodeDelete', 'catalog', '', 'CCatalogStoreDocsElement', 'OnDocumentBarcodeDelete', '', 1),
(108, '2015-04-14 06:29:15', 100, 'catalog', 'OnBeforeDocumentDelete', 'catalog', '', 'CCatalogStoreDocsBarcode', 'OnBeforeDocumentDelete', '', 1),
(109, '2015-04-14 06:29:15', 100, 'catalog', 'OnCatalogStoreDelete', 'catalog', '', 'CCatalogDocs', 'OnCatalogStoreDelete', '', 1),
(110, '2015-04-14 06:29:15', 100, 'iblock', 'OnBeforeIBlockPropertyDelete', 'catalog', '', 'CCatalog', 'OnBeforeIBlockPropertyDelete', '', 1),
(111, '2015-04-14 06:29:15', 1100, 'sale', 'OnCondSaleControlBuildList', 'catalog', '', 'CCatalogCondCtrlBasketProductFields', 'GetControlDescr', '', 1),
(112, '2015-04-14 06:29:15', 1200, 'sale', 'OnCondSaleControlBuildList', 'catalog', '', 'CCatalogCondCtrlBasketProductProps', 'GetControlDescr', '', 1),
(113, '2015-04-14 06:29:15', 1200, 'sale', 'OnCondSaleActionsControlBuildList', 'catalog', '', 'CCatalogActionCtrlBasketProductFields', 'GetControlDescr', '', 1),
(114, '2015-04-14 06:29:15', 1300, 'sale', 'OnCondSaleActionsControlBuildList', 'catalog', '', 'CCatalogActionCtrlBasketProductProps', 'GetControlDescr', '', 1),
(115, '2015-04-14 06:29:15', 100, 'sale', 'OnExtendBasketItems', 'catalog', '', 'CCatalogDiscount', 'ExtendBasketItems', '', 1),
(116, '2015-04-14 06:29:15', 100, 'iblock', 'OnModuleUnInstall', 'catalog', '', 'CCatalog', 'OnIBlockModuleUnInstall', '', 1),
(117, '2015-04-14 06:29:17', 100, 'main', 'OnEventLogGetAuditTypes', 'clouds', '', 'CCloudStorage', 'GetAuditTypes', '', 1),
(118, '2015-04-14 06:29:17', 100, 'main', 'OnBeforeProlog', 'clouds', '', 'CCloudStorage', 'OnBeforeProlog', '', 1),
(119, '2015-04-14 06:29:17', 100, 'main', 'OnAdminListDisplay', 'clouds', '', 'CCloudStorage', 'OnAdminListDisplay', '', 1),
(120, '2015-04-14 06:29:17', 100, 'main', 'OnBuildGlobalMenu', 'clouds', '', 'CCloudStorage', 'OnBuildGlobalMenu', '', 1),
(121, '2015-04-14 06:29:17', 100, 'main', 'OnFileSave', 'clouds', '', 'CCloudStorage', 'OnFileSave', '', 1),
(122, '2015-04-14 06:29:17', 100, 'main', 'OnGetFileSRC', 'clouds', '', 'CCloudStorage', 'OnGetFileSRC', '', 1),
(123, '2015-04-14 06:29:17', 100, 'main', 'OnFileCopy', 'clouds', '', 'CCloudStorage', 'OnFileCopy', '', 1),
(124, '2015-04-14 06:29:17', 100, 'main', 'OnFileDelete', 'clouds', '', 'CCloudStorage', 'OnFileDelete', '', 1),
(125, '2015-04-14 06:29:17', 100, 'main', 'OnMakeFileArray', 'clouds', '', 'CCloudStorage', 'OnMakeFileArray', '', 1),
(126, '2015-04-14 06:29:17', 100, 'main', 'OnBeforeResizeImage', 'clouds', '', 'CCloudStorage', 'OnBeforeResizeImage', '', 1),
(127, '2015-04-14 06:29:17', 100, 'main', 'OnAfterResizeImage', 'clouds', '', 'CCloudStorage', 'OnAfterResizeImage', '', 1),
(128, '2015-04-14 06:29:17', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_AmazonS3', 'GetObject', '', 1),
(129, '2015-04-14 06:29:17', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_GoogleStorage', 'GetObject', '', 1),
(130, '2015-04-14 06:29:17', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_OpenStackStorage', 'GetObject', '', 1),
(131, '2015-04-14 06:29:17', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_RackSpaceCloudFiles', 'GetObject', '', 1),
(132, '2015-04-14 06:29:17', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_ClodoRU', 'GetObject', '', 1),
(133, '2015-04-14 06:29:17', 100, 'clouds', 'OnGetStorageService', 'clouds', '', 'CCloudStorageService_Selectel', 'GetObject', '', 1),
(134, '2015-04-14 06:29:19', 1, 'main', 'OnPageStart', 'compression', '', 'CCompress', 'OnPageStart', '', 1),
(135, '2015-04-14 06:29:19', 10000, 'main', 'OnAfterEpilog', 'compression', '', 'CCompress', 'OnAfterEpilog', '', 1),
(136, '2015-04-14 06:29:21', 100, 'main', 'OnGroupDelete', 'fileman', '', 'CFileman', 'OnGroupDelete', '', 1),
(137, '2015-04-14 06:29:21', 100, 'main', 'OnPanelCreate', 'fileman', '', 'CFileman', 'OnPanelCreate', '', 1),
(138, '2015-04-14 06:29:21', 100, 'main', 'OnModuleUpdate', 'fileman', '', 'CFileman', 'OnModuleUpdate', '', 1),
(139, '2015-04-14 06:29:21', 100, 'main', 'OnModuleInstalled', 'fileman', '', 'CFileman', 'ClearComponentsListCache', '', 1),
(140, '2015-04-14 06:29:21', 100, 'iblock', 'OnIBlockPropertyBuildList', 'fileman', '', 'CIBlockPropertyMapGoogle', 'GetUserTypeDescription', '', 1),
(141, '2015-04-14 06:29:21', 100, 'iblock', 'OnIBlockPropertyBuildList', 'fileman', '', 'CIBlockPropertyMapYandex', 'GetUserTypeDescription', '', 1),
(142, '2015-04-14 06:29:21', 100, 'iblock', 'OnIBlockPropertyBuildList', 'fileman', '', 'CIBlockPropertyVideo', 'GetUserTypeDescription', '', 1),
(143, '2015-04-14 06:29:21', 100, 'main', 'OnUserTypeBuildList', 'fileman', '', 'CUserTypeVideo', 'GetUserTypeDescription', '', 1),
(144, '2015-04-14 06:29:21', 100, 'main', 'OnEventLogGetAuditTypes', 'fileman', '', 'CEventFileman', 'GetAuditTypes', '', 1),
(145, '2015-04-14 06:29:21', 100, 'main', 'OnEventLogGetAuditHandlers', 'fileman', '', 'CEventFileman', 'MakeFilemanObject', '', 1),
(146, '2015-04-14 06:29:26', 100, 'main', 'OnGroupDelete', 'forum', '', 'CForumNew', 'OnGroupDelete', '', 1),
(147, '2015-04-14 06:29:26', 100, 'main', 'OnBeforeLangDelete', 'forum', '', 'CForumNew', 'OnBeforeLangDelete', '', 1),
(148, '2015-04-14 06:29:26', 100, 'main', 'OnFileDelete', 'forum', '', 'CForumFiles', 'OnFileDelete', '', 1),
(149, '2015-04-14 06:29:26', 100, 'search', 'OnReindex', 'forum', '', 'CForumNew', 'OnReindex', '', 1),
(150, '2015-04-14 06:29:26', 100, 'main', 'OnUserDelete', 'forum', '', 'CForumUser', 'OnUserDelete', '', 1),
(151, '2015-04-14 06:29:26', 100, 'iblock', 'OnIBlockPropertyBuildList', 'main', '/modules/forum/tools/prop_topicid.php', 'CIBlockPropertyTopicID', 'GetUserTypeDescription', '', 1),
(152, '2015-04-14 06:29:26', 100, 'iblock', 'OnBeforeIBlockElementDelete', 'forum', '', 'CForumTopic', 'OnBeforeIBlockElementDelete', '', 1),
(153, '2015-04-14 06:29:26', 100, 'main', 'OnEventLogGetAuditTypes', 'forum', '', 'CForumEventLog', 'GetAuditTypes', '', 1),
(154, '2015-04-14 06:29:26', 100, 'main', 'OnEventLogGetAuditHandlers', 'forum', '', 'CEventForum', 'MakeForumObject', '', 1),
(155, '2015-04-14 06:29:26', 100, 'socialnetwork', 'OnSocNetGroupDelete', 'forum', '', 'CForumUser', 'OnSocNetGroupDelete', '', 1),
(156, '2015-04-14 06:29:26', 100, 'socialnetwork', 'OnSocNetLogFormatEvent', 'forum', '', 'CForumMessage', 'OnSocNetLogFormatEvent', '', 1),
(157, '2015-04-14 06:29:26', 100, 'mail', 'OnGetFilterList', 'forum', '', 'CForumEMail', 'OnGetSocNetFilterList', '', 1),
(158, '2015-04-14 06:29:26', 100, 'main', 'OnAfterAddRating', 'forum', '', 'CRatingsComponentsForum', 'OnAfterAddRating', '', 1),
(159, '2015-04-14 06:29:26', 100, 'main', 'OnAfterUpdateRating', 'forum', '', 'CRatingsComponentsForum', 'OnAfterUpdateRating', '', 1),
(160, '2015-04-14 06:29:26', 100, 'main', 'OnSetRatingsConfigs', 'forum', '', 'CRatingsComponentsForum', 'OnSetRatingConfigs', '', 1),
(161, '2015-04-14 06:29:26', 100, 'main', 'OnGetRatingsConfigs', 'forum', '', 'CRatingsComponentsForum', 'OnGetRatingConfigs', '', 1),
(162, '2015-04-14 06:29:26', 100, 'main', 'OnGetRatingsObjects', 'forum', '', 'CRatingsComponentsForum', 'OnGetRatingObject', '', 1),
(163, '2015-04-14 06:29:26', 100, 'main', 'OnGetRatingContentOwner', 'forum', '', 'CRatingsComponentsForum', 'OnGetRatingContentOwner', '', 1),
(164, '2015-04-14 06:29:26', 100, 'im', 'OnGetNotifySchema', 'forum', '', 'CForumNotifySchema', 'OnGetNotifySchema', '', 1),
(165, '2015-04-14 06:29:26', 100, 'main', 'OnAfterRegisterModule', 'main', '/modules/forum/install/index.php', 'forum', 'InstallUserFields', '', 1),
(166, '2015-04-14 06:29:32', 100, 'main', 'OnBeforeUserTypeAdd', 'highloadblock', '', '\\Bitrix\\Highloadblock\\HighloadBlockTable', 'OnBeforeUserTypeAdd', '', 1),
(167, '2015-04-14 06:29:32', 100, 'main', 'OnAfterUserTypeAdd', 'highloadblock', '', '\\Bitrix\\Highloadblock\\HighloadBlockTable', 'onAfterUserTypeAdd', '', 1),
(168, '2015-04-14 06:29:32', 100, 'main', 'OnBeforeUserTypeDelete', 'highloadblock', '', '\\Bitrix\\Highloadblock\\HighloadBlockTable', 'OnBeforeUserTypeDelete', '', 1),
(169, '2015-04-14 06:29:32', 100, 'main', 'OnUserTypeBuildList', 'highloadblock', '', 'CUserTypeHlblock', 'GetUserTypeDescription', '', 1),
(170, '2015-04-14 06:29:32', 100, 'iblock', 'OnIBlockPropertyBuildList', 'highloadblock', '', 'CIBlockPropertyDirectory', 'GetUserTypeDescription', '', 1),
(171, '2015-04-14 06:29:34', 100, 'main', 'OnGroupDelete', 'iblock', '', 'CIBlock', 'OnGroupDelete', '', 1),
(172, '2015-04-14 06:29:34', 100, 'main', 'OnBeforeLangDelete', 'iblock', '', 'CIBlock', 'OnBeforeLangDelete', '', 1),
(173, '2015-04-14 06:29:34', 100, 'main', 'OnLangDelete', 'iblock', '', 'CIBlock', 'OnLangDelete', '', 1),
(174, '2015-04-14 06:29:34', 100, 'main', 'OnUserTypeRightsCheck', 'iblock', '', 'CIBlockSection', 'UserTypeRightsCheck', '', 1),
(175, '2015-04-14 06:29:34', 100, 'search', 'OnReindex', 'iblock', '', 'CIBlock', 'OnSearchReindex', '', 1),
(176, '2015-04-14 06:29:34', 100, 'search', 'OnSearchGetURL', 'iblock', '', 'CIBlock', 'OnSearchGetURL', '', 1),
(177, '2015-04-14 06:29:34', 100, 'main', 'OnEventLogGetAuditTypes', 'iblock', '', 'CIBlock', 'GetAuditTypes', '', 1),
(178, '2015-04-14 06:29:34', 100, 'main', 'OnEventLogGetAuditHandlers', 'iblock', '', 'CEventIBlock', 'MakeIBlockObject', '', 1),
(179, '2015-04-14 06:29:34', 200, 'main', 'OnGetRatingContentOwner', 'iblock', '', 'CRatingsComponentsIBlock', 'OnGetRatingContentOwner', '', 1),
(180, '2015-04-14 06:29:34', 100, 'main', 'OnTaskOperationsChanged', 'iblock', '', 'CIBlockRightsStorage', 'OnTaskOperationsChanged', '', 1),
(181, '2015-04-14 06:29:34', 100, 'main', 'OnGroupDelete', 'iblock', '', 'CIBlockRightsStorage', 'OnGroupDelete', '', 1),
(182, '2015-04-14 06:29:34', 100, 'main', 'OnUserDelete', 'iblock', '', 'CIBlockRightsStorage', 'OnUserDelete', '', 1),
(183, '2015-04-14 06:29:34', 100, 'perfmon', 'OnGetTableSchema', 'iblock', '', 'iblock', 'OnGetTableSchema', '', 1),
(184, '2015-04-14 06:29:34', 100, 'sender', 'OnConnectorList', 'iblock', '', '\\Bitrix\\Iblock\\SenderEventHandler', 'onConnectorListIblock', '', 1),
(185, '2015-04-14 06:29:34', 10, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_DateTime_GetUserTypeDescription', '', 1),
(186, '2015-04-14 06:29:34', 20, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_XmlID_GetUserTypeDescription', '', 1),
(187, '2015-04-14 06:29:34', 30, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_FileMan_GetUserTypeDescription', '', 1),
(188, '2015-04-14 06:29:34', 40, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_HTML_GetUserTypeDescription', '', 1),
(189, '2015-04-14 06:29:34', 50, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_ElementList_GetUserTypeDescription', '', 1),
(190, '2015-04-14 06:29:34', 60, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_Sequence_GetUserTypeDescription', '', 1),
(191, '2015-04-14 06:29:34', 70, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_ElementAutoComplete_GetUserTypeDescription', '', 1),
(192, '2015-04-14 06:29:34', 80, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_SKU_GetUserTypeDescription', '', 1),
(193, '2015-04-14 06:29:34', 90, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_SectionAutoComplete_GetUserTypeDescription', '', 1),
(194, '2015-04-14 06:29:40', 100, 'socialnetwork', 'OnFillSocNetLogEvents', 'idea', '', 'CIdeaManagmentSonetNotify', 'AddLogEvent', '', 1),
(195, '2015-04-14 06:29:42', 100, 'main', 'OnAddRatingVote', 'im', '', 'CIMEvent', 'OnAddRatingVote', '', 1),
(196, '2015-04-14 06:29:42', 100, 'main', 'OnCancelRatingVote', 'im', '', 'CIMEvent', 'OnCancelRatingVote', '', 1),
(197, '2015-04-14 06:29:42', 100, 'main', 'OnAfterUserUpdate', 'im', '', 'CIMEvent', 'OnAfterUserUpdate', '', 1),
(198, '2015-04-14 06:29:42', 100, 'main', 'OnUserDelete', 'im', '', 'CIMEvent', 'OnUserDelete', '', 1),
(199, '2015-04-14 06:29:42', 100, 'pull', 'OnGetDependentModule', 'im', '', 'CIMEvent', 'OnGetDependentModule', '', 1),
(200, '2015-04-14 06:29:42', 3, 'main', 'OnProlog', 'main', '/modules/im/ajax_hit.php', '', '', '', 1),
(201, '2015-04-14 06:29:42', 100, 'perfmon', 'OnGetTableSchema', 'im', '', 'CIMTableSchema', 'OnGetTableSchema', '', 1),
(202, '2015-04-14 06:29:42', 100, 'im', 'OnGetNotifySchema', 'im', '', 'CIMNotifySchema', 'OnGetNotifySchema', '', 1),
(203, '2015-04-14 06:29:42', 100, 'main', 'OnFileDelete', 'im', '', 'CIMEvent', 'OnFileDelete', '', 1),
(204, '2015-04-14 06:29:42', 100, 'main', 'OnApplicationsBuildList', 'im', '', 'DesktopApplication', 'OnApplicationsBuildList', '', 1),
(205, '2015-04-14 06:29:43', 1, 'main', 'OnUserLoginExternal', 'ldap', '', 'CLdap', 'OnUserLogin', '', 1),
(206, '2015-04-14 06:29:43', 100, 'main', 'OnExternalAuthList', 'ldap', '', 'CLdap', 'OnExternalAuthList', '', 1),
(207, '2015-04-14 06:29:44', 100, 'main', 'OnGroupDelete', 'learning', '', 'CCourse', 'OnGroupDelete', '', 1),
(208, '2015-04-14 06:29:44', 100, 'main', 'OnBeforeLangDelete', 'learning', '', 'CCourse', 'OnBeforeLangDelete', '', 1),
(209, '2015-04-14 06:29:44', 100, 'main', 'OnUserDelete', 'learning', '', 'CCourse', 'OnUserDelete', '', 1),
(210, '2015-04-14 06:29:44', 100, 'main', 'OnSiteDelete', 'learning', '', 'CSitePath', 'DeleteBySiteID', '', 1),
(211, '2015-04-14 06:29:44', 100, 'search', 'OnReindex', 'learning', '', 'CCourse', 'OnSearchReindex', '', 1),
(212, '2015-04-14 06:29:44', 200, 'main', 'OnGetRatingContentOwner', 'learning', '', 'CRatingsComponentsLearning', 'OnGetRatingContentOwner', '', 1),
(213, '2015-04-14 06:29:44', 200, 'main', 'OnAddRatingVote', 'learning', '', 'CRatingsComponentsLearning', 'OnAddRatingVote', '', 1),
(214, '2015-04-14 06:29:44', 200, 'main', 'OnCancelRatingVote', 'learning', '', 'CRatingsComponentsLearning', 'OnCancelRatingVote', '', 1),
(215, '2015-04-14 06:29:44', 100, 'main', 'OnEventLogGetAuditTypes', 'learning', '', 'CLearningEvent', 'GetAuditTypes', '', 1),
(216, '2015-04-14 06:29:44', 100, 'main', 'OnEventLogGetAuditHandlers', 'learning', '', 'CLearningEvent', 'MakeMainObject', '', 1),
(217, '2015-04-14 06:29:44', 100, 'learning', 'OnAfterLearningGroupDelete', 'learning', '', 'CLearningGroupMember', 'onAfterLearningGroupDelete', '', 1),
(218, '2015-04-14 06:29:44', 100, 'learning', 'OnAfterLearningGroupDelete', 'learning', '', 'CLearningGroupLesson', 'onAfterLearningGroupDelete', '', 1),
(219, '2015-04-14 06:29:46', 100, 'iblock', 'OnIBlockDelete', 'lists', '', 'CLists', 'OnIBlockDelete', '', 1),
(220, '2015-04-14 06:29:46', 100, 'iblock', 'CIBlockDocument_OnGetDocumentAdminPage', 'lists', '', 'CList', 'OnGetDocumentAdminPage', '', 1),
(221, '2015-04-14 06:29:46', 100, 'intranet', 'OnSharepointCreateProperty', 'lists', '', 'CLists', 'OnSharepointCreateProperty', '', 1),
(222, '2015-04-14 06:29:46', 100, 'intranet', 'OnSharepointCheckAccess', 'lists', '', 'CLists', 'OnSharepointCheckAccess', '', 1),
(223, '2015-04-14 06:29:46', 100, 'perfmon', 'OnGetTableSchema', 'lists', '', 'lists', 'OnGetTableSchema', '', 1),
(224, '2015-04-14 06:29:46', 50, 'search', 'OnSearchGetURL', 'lists', '', 'CList', 'OnSearchGetURL', '', 1),
(225, '2015-04-14 06:29:48', 100, 'rest', 'OnRestServiceBuildDescription', 'mail', '', 'CMailRestService', 'OnRestServiceBuildDescription', '', 1),
(226, '2015-04-14 06:29:49', 100, 'pull', 'OnGetDependentModule', 'mobileapp', '', 'CMobileAppPullSchema', 'OnGetDependentModule', '', 1),
(227, '2015-04-14 06:29:52', 100, 'iblock', 'OnBeforeIBlockElementDelete', 'photogallery', '', 'CPhotogalleryElement', 'OnBeforeIBlockElementDelete', '', 1),
(228, '2015-04-14 06:29:52', 100, 'iblock', 'OnAfterIBlockElementAdd', 'photogallery', '', 'CPhotogalleryElement', 'OnAfterIBlockElementAdd', '', 1),
(229, '2015-04-14 06:29:52', 100, 'search', 'BeforeIndex', 'photogallery', '', 'CRatingsComponentsPhotogallery', 'BeforeIndex', '', 1),
(230, '2015-04-14 06:29:52', 100, 'im', 'OnGetNotifySchema', 'photogallery', '', 'CPhotogalleryNotifySchema', 'OnGetNotifySchema', '', 1),
(231, '2015-04-14 06:29:55', 3, 'main', 'OnProlog', 'main', '/modules/pull/ajax_hit.php', '', '', '', 1),
(232, '2015-04-14 06:29:55', 100, 'main', 'OnEpilog', 'pull', '', 'CPullWatch', 'DeferredSql', '', 1),
(233, '2015-04-14 06:29:55', 100, 'main', 'OnEpilog', 'pull', '', 'CPullOptions', 'OnEpilog', '', 1),
(234, '2015-04-14 06:29:55', 100, 'perfmon', 'OnGetTableSchema', 'pull', '', 'CPullTableSchema', 'OnGetTableSchema', '', 1),
(235, '2015-04-14 06:29:55', 100, 'main', 'OnAfterRegisterModule', 'pull', '', 'CPullOptions', 'ClearCheckCache', '', 1),
(236, '2015-04-14 06:29:55', 100, 'main', 'OnAfterUnRegisterModule', 'pull', '', 'CPullOptions', 'ClearCheckCache', '', 1),
(237, '2015-04-14 06:30:00', 100, 'main', 'OnUserLogin', 'sale', '', 'CSaleUser', 'OnUserLogin', '', 1),
(238, '2015-04-14 06:30:00', 100, 'main', 'OnUserLogout', 'sale', '', 'CSaleUser', 'OnUserLogout', '', 1),
(239, '2015-04-14 06:30:00', 100, 'main', 'OnBeforeLangDelete', 'sale', '', 'CSalePersonType', 'OnBeforeLangDelete', '', 1),
(240, '2015-04-14 06:30:00', 100, 'main', 'OnLanguageDelete', 'sale', '', 'CSaleLocation', 'OnLangDelete', '', 1),
(241, '2015-04-14 06:30:00', 100, 'main', 'OnLanguageDelete', 'sale', '', 'CSaleLocationGroup', 'OnLangDelete', '', 1),
(242, '2015-04-14 06:30:00', 100, 'main', 'OnUserDelete', 'sale', '', 'CSaleOrderUserProps', 'OnUserDelete', '', 1),
(243, '2015-04-14 06:30:00', 100, 'main', 'OnUserDelete', 'sale', '', 'CSaleUserAccount', 'OnUserDelete', '', 1),
(244, '2015-04-14 06:30:00', 100, 'main', 'OnUserDelete', 'sale', '', 'CSaleAuxiliary', 'OnUserDelete', '', 1),
(245, '2015-04-14 06:30:00', 100, 'main', 'OnUserDelete', 'sale', '', 'CSaleUser', 'OnUserDelete', '', 1),
(246, '2015-04-14 06:30:00', 100, 'main', 'OnUserDelete', 'sale', '', 'CSaleRecurring', 'OnUserDelete', '', 1),
(247, '2015-04-14 06:30:00', 100, 'main', 'OnUserDelete', 'sale', '', 'CSaleUserCards', 'OnUserDelete', '', 1),
(248, '2015-04-14 06:30:00', 100, 'main', 'OnBeforeUserDelete', 'sale', '', 'CSaleOrder', 'OnBeforeUserDelete', '', 1),
(249, '2015-04-14 06:30:00', 100, 'main', 'OnBeforeUserDelete', 'sale', '', 'CSaleAffiliate', 'OnBeforeUserDelete', '', 1),
(250, '2015-04-14 06:30:00', 100, 'main', 'OnBeforeUserDelete', 'sale', '', 'CSaleUserAccount', 'OnBeforeUserDelete', '', 1),
(251, '2015-04-14 06:30:00', 100, 'main', 'OnBeforeProlog', 'main', '/modules/sale/affiliate.php', '', '', '', 1),
(252, '2015-04-14 06:30:00', 100, 'main', 'OnEventLogGetAuditTypes', 'sale', '', 'CSaleYMHandler', 'OnEventLogGetAuditTypes', '', 1),
(253, '2015-04-14 06:30:00', 100, 'currency', 'OnBeforeCurrencyDelete', 'sale', '', 'CSaleOrder', 'OnBeforeCurrencyDelete', '', 1),
(254, '2015-04-14 06:30:00', 100, 'currency', 'OnBeforeCurrencyDelete', 'sale', '', 'CSaleLang', 'OnBeforeCurrencyDelete', '', 1),
(255, '2015-04-14 06:30:00', 100, 'currency', 'OnModuleUnInstall', 'sale', '', '', 'CurrencyModuleUnInstallSale', '', 1),
(256, '2015-04-14 06:30:00', 100, 'catalog', 'OnSaleOrderSumm', 'sale', '', 'CSaleOrder', '__SaleOrderCount', '', 1),
(257, '2015-04-14 06:30:00', 100, 'mobileapp', 'OnBeforeAdminMobileMenuBuild', 'sale', '', 'CSaleMobileOrderUtils', 'buildSaleAdminMobileMenu', '', 1),
(258, '2015-04-14 06:30:00', 100, 'sender', 'OnConnectorList', 'sale', '', '\\Bitrix\\Sale\\SenderEventHandler', 'onConnectorListBuyer', '', 1),
(259, '2015-04-14 06:30:00', 100, 'sale', 'OnCondSaleControlBuildList', 'sale', '', 'CSaleCondCtrlGroup', 'GetControlDescr', '', 1),
(260, '2015-04-14 06:30:00', 200, 'sale', 'OnCondSaleControlBuildList', 'sale', '', 'CSaleCondCtrlBasketGroup', 'GetControlDescr', '', 1),
(261, '2015-04-14 06:30:00', 300, 'sale', 'OnCondSaleControlBuildList', 'sale', '', 'CSaleCondCtrlBasketFields', 'GetControlDescr', '', 1),
(262, '2015-04-14 06:30:00', 1000, 'sale', 'OnCondSaleControlBuildList', 'sale', '', 'CSaleCondCtrlOrderFields', 'GetControlDescr', '', 1),
(263, '2015-04-14 06:30:00', 10000, 'sale', 'OnCondSaleControlBuildList', 'sale', '', 'CSaleCondCtrlCommon', 'GetControlDescr', '', 1),
(264, '2015-04-14 06:30:00', 100, 'sale', 'OnCondSaleActionsControlBuildList', 'sale', '', 'CSaleActionCtrlGroup', 'GetControlDescr', '', 1),
(265, '2015-04-14 06:30:00', 200, 'sale', 'OnCondSaleActionsControlBuildList', 'sale', '', 'CSaleActionCtrlDelivery', 'GetControlDescr', '', 1),
(266, '2015-04-14 06:30:00', 300, 'sale', 'OnCondSaleActionsControlBuildList', 'sale', '', 'CSaleActionCtrlBasketGroup', 'GetControlDescr', '', 1),
(267, '2015-04-14 06:30:00', 1000, 'sale', 'OnCondSaleActionsControlBuildList', 'sale', '', 'CSaleActionCtrlSubGroup', 'GetControlDescr', '', 1),
(268, '2015-04-14 06:30:00', 1100, 'sale', 'OnCondSaleActionsControlBuildList', 'sale', '', 'CSaleActionCondCtrlBasketFields', 'GetControlDescr', '', 1),
(269, '2015-04-14 06:30:00', 100, 'sale', 'OnOrderDelete', 'sale', '', 'CSaleMobileOrderPull', 'onOrderDelete', '', 1),
(270, '2015-04-14 06:30:00', 100, 'sale', 'OnOrderAdd', 'sale', '', 'CSaleMobileOrderPull', 'onOrderAdd', '', 1),
(271, '2015-04-14 06:30:00', 100, 'sale', 'OnOrderUpdate', 'sale', '', 'CSaleMobileOrderPull', 'onOrderUpdate', '', 1),
(272, '2015-04-14 06:30:00', 100, 'sale', 'OnBasketOrder', 'sale', '', '\\Bitrix\\Sale\\Product2ProductTable', 'onSaleOrderAdd', '', 1),
(273, '2015-04-14 06:30:00', 100, 'sale', 'OnSaleStatusOrder', 'sale', '', '\\Bitrix\\Sale\\Product2ProductTable', 'onSaleStatusOrderHandler', '', 1),
(274, '2015-04-14 06:30:00', 100, 'sale', 'OnSaleDeliveryOrder', 'sale', '', '\\Bitrix\\Sale\\Product2ProductTable', 'onSaleDeliveryOrderHandler', '', 1),
(275, '2015-04-14 06:30:00', 100, 'sale', 'OnSaleDeductOrder', 'sale', '', '\\Bitrix\\Sale\\Product2ProductTable', 'onSaleDeductOrderHandler', '', 1),
(276, '2015-04-14 06:30:00', 100, 'sale', 'OnSaleCancelOrder', 'sale', '', '\\Bitrix\\Sale\\Product2ProductTable', 'onSaleCancelOrderHandler', '', 1),
(277, '2015-04-14 06:30:00', 100, 'sale', 'OnSalePayOrder', 'sale', '', '\\Bitrix\\Sale\\Product2ProductTable', 'onSalePayOrderHandler', '', 1),
(278, '2015-04-14 06:30:06', 100, 'main', 'OnEventLogGetAuditTypes', 'scale', '', '\\Bitrix\\Scale\\Logger', 'onEventLogGetAuditTypes', '', 1),
(279, '2015-04-14 06:30:07', 100, 'main', 'OnChangePermissions', 'search', '', 'CSearch', 'OnChangeFilePermissions', '', 1),
(280, '2015-04-14 06:30:07', 100, 'main', 'OnChangeFile', 'search', '', 'CSearch', 'OnChangeFile', '', 1),
(281, '2015-04-14 06:30:07', 100, 'main', 'OnGroupDelete', 'search', '', 'CSearch', 'OnGroupDelete', '', 1),
(282, '2015-04-14 06:30:07', 100, 'main', 'OnLangDelete', 'search', '', 'CSearch', 'OnLangDelete', '', 1),
(283, '2015-04-14 06:30:07', 100, 'main', 'OnAfterUserUpdate', 'search', '', 'CSearchUser', 'OnAfterUserUpdate', '', 1),
(284, '2015-04-14 06:30:07', 100, 'main', 'OnUserDelete', 'search', '', 'CSearchUser', 'DeleteByUserID', '', 1),
(285, '2015-04-14 06:30:07', 100, 'cluster', 'OnGetTableList', 'search', '', 'search', 'OnGetTableList', '', 1),
(286, '2015-04-14 06:30:07', 100, 'perfmon', 'OnGetTableSchema', 'search', '', 'search', 'OnGetTableSchema', '', 1),
(287, '2015-04-14 06:30:07', 90, 'main', 'OnEpilog', 'search', '', 'CSearchStatistic', 'OnEpilog', '', 1),
(288, '2015-04-14 06:30:09', 100, 'main', 'OnUserDelete', 'security', '', 'CSecurityUser', 'OnUserDelete', '', 1),
(289, '2015-04-14 06:30:09', 100, 'main', 'OnEventLogGetAuditTypes', 'security', '', 'CSecurityFilter', 'GetAuditTypes', '', 1),
(290, '2015-04-14 06:30:09', 100, 'main', 'OnEventLogGetAuditTypes', 'security', '', 'CSecurityAntiVirus', 'GetAuditTypes', '', 1),
(291, '2015-04-14 06:30:09', 100, 'main', 'OnAdminInformerInsertItems', 'security', '', 'CSecurityFilter', 'OnAdminInformerInsertItems', '', 1),
(292, '2015-04-14 06:30:09', 100, 'main', 'OnAdminInformerInsertItems', 'security', '', 'CSecuritySiteChecker', 'OnAdminInformerInsertItems', '', 1),
(293, '2015-04-14 06:30:09', 5, 'main', 'OnBeforeProlog', 'security', '', 'CSecurityFilter', 'OnBeforeProlog', '', 1),
(294, '2015-04-14 06:30:09', 9999, 'main', 'OnEndBufferContent', 'security', '', 'CSecurityXSSDetect', 'OnEndBufferContent', '', 1),
(295, '2015-04-14 06:30:09', -1, 'main', 'OnPageStart', 'security', '', 'CSecurityAntiVirus', 'OnPageStart', '', 1),
(296, '2015-04-14 06:30:09', 10000, 'main', 'OnEndBufferContent', 'security', '', 'CSecurityAntiVirus', 'OnEndBufferContent', '', 1),
(297, '2015-04-14 06:30:09', 10001, 'main', 'OnAfterEpilog', 'security', '', 'CSecurityAntiVirus', 'OnAfterEpilog', '', 1),
(298, '2015-04-14 06:30:10', 100, 'main', 'OnPanelCreate', 'seo', '', 'CSeoEventHandlers', 'SeoOnPanelCreate', '', 2),
(299, '2015-04-14 06:30:10', 100, 'fileman', 'OnIncludeHTMLEditorScript', 'seo', '', 'CSeoEventHandlers', 'OnIncludeHTMLEditorScript', '', 2),
(300, '2015-04-14 06:30:10', 100, 'fileman', 'OnBeforeHTMLEditorScriptRuns', 'seo', '', 'CSeoEventHandlers', 'OnBeforeHTMLEditorScriptRuns', '', 2),
(301, '2015-04-14 06:30:10', 100, 'iblock', 'OnAfterIBlockSectionAdd', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'addSection', '', 2),
(302, '2015-04-14 06:30:10', 100, 'iblock', 'OnAfterIBlockElementAdd', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'addElement', '', 2),
(303, '2015-04-14 06:30:10', 100, 'iblock', 'OnBeforeIBlockSectionDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'beforeDeleteSection', '', 2),
(304, '2015-04-14 06:30:10', 100, 'iblock', 'OnBeforeIBlockElementDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'beforeDeleteElement', '', 2),
(305, '2015-04-14 06:30:10', 100, 'iblock', 'OnAfterIBlockSectionDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'deleteSection', '', 2),
(306, '2015-04-14 06:30:10', 100, 'iblock', 'OnAfterIBlockElementDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'deleteElement', '', 2),
(307, '2015-04-14 06:30:10', 100, 'iblock', 'OnBeforeIBlockSectionUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'beforeUpdateSection', '', 2),
(308, '2015-04-14 06:30:10', 100, 'iblock', 'OnBeforeIBlockElementUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'beforeUpdateElement', '', 2),
(309, '2015-04-14 06:30:10', 100, 'iblock', 'OnAfterIBlockSectionUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'updateSection', '', 2),
(310, '2015-04-14 06:30:10', 100, 'iblock', 'OnAfterIBlockElementUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapIblock', 'updateElement', '', 2),
(311, '2015-04-14 06:30:10', 100, 'forum', 'onAfterTopicAdd', 'seo', '', '\\Bitrix\\Seo\\SitemapForum', 'addTopic', '', 2),
(312, '2015-04-14 06:30:10', 100, 'forum', 'onAfterTopicUpdate', 'seo', '', '\\Bitrix\\Seo\\SitemapForum', 'updateTopic', '', 2),
(313, '2015-04-14 06:30:10', 100, 'forum', 'onAfterTopicDelete', 'seo', '', '\\Bitrix\\Seo\\SitemapForum', 'deleteTopic', '', 2),
(314, '2015-04-14 06:30:10', 100, 'main', 'OnAdminIBlockElementEdit', 'seo', '', '\\Bitrix\\Seo\\AdvTabEngine', 'eventHandler', '', 2),
(315, '2015-04-14 06:30:10', 100, 'main', 'OnBeforeProlog', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'checkSession', '', 2),
(316, '2015-04-14 06:30:13', 100, 'search', 'OnBeforeFullReindexClear', 'socialnetwork', '', 'CSocNetSearchReindex', 'OnBeforeFullReindexClear', '', 1),
(317, '2015-04-14 06:30:13', 100, 'search', 'OnBeforeIndexDelete', 'socialnetwork', '', 'CSocNetSearchReindex', 'OnBeforeIndexDelete', '', 1),
(318, '2015-04-14 06:30:13', 100, 'search', 'OnReindex', 'socialnetwork', '', 'CSocNetSearch', 'OnSearchReindex', '', 1),
(319, '2015-04-14 06:30:13', 100, 'search', 'OnSearchCheckPermissions', 'socialnetwork', '', 'CSocNetSearch', 'OnSearchCheckPermissions', '', 1),
(320, '2015-04-14 06:30:13', 100, 'search', 'OnBeforeIndexUpdate', 'socialnetwork', '', 'CSocNetSearch', 'OnBeforeIndexUpdate', '', 1),
(321, '2015-04-14 06:30:13', 100, 'search', 'OnAfterIndexAdd', 'socialnetwork', '', 'CSocNetSearch', 'OnAfterIndexAdd', '', 1),
(322, '2015-04-14 06:30:13', 100, 'search', 'OnSearchPrepareFilter', 'socialnetwork', '', 'CSocNetSearch', 'OnSearchPrepareFilter', '', 1),
(323, '2015-04-14 06:30:13', 100, 'main', 'OnUserDelete', 'socialnetwork', '', 'CSocNetUser', 'OnUserDelete', '', 1),
(324, '2015-04-14 06:30:13', 100, 'main', 'OnBeforeUserUpdate', 'socialnetwork', '', 'CSocNetUser', 'OnBeforeUserUpdate', '', 1),
(325, '2015-04-14 06:30:13', 100, 'main', 'OnAfterUserUpdate', 'socialnetwork', '', 'CSocNetUser', 'OnAfterUserUpdate', '', 1),
(326, '2015-04-14 06:30:13', 100, 'main', 'OnAfterUserAdd', 'socialnetwork', '', 'CSocNetUser', 'OnAfterUserAdd', '', 1),
(327, '2015-04-14 06:30:13', 100, 'main', 'OnAfterUserLogout', 'socialnetwork', '', 'CSocNetUser', 'OnAfterUserLogout', '', 1),
(328, '2015-04-14 06:30:13', 100, 'main', 'OnBeforeProlog', 'main', '/modules/socialnetwork/prolog_before.php', '', '', '', 1),
(329, '2015-04-14 06:30:13', 100, 'main', 'OnBeforeLangDelete', 'socialnetwork', '', 'CSocNetGroup', 'OnBeforeLangDelete', '', 1),
(330, '2015-04-14 06:30:13', 100, 'socialnetwork', 'OnSocNetLogFormatEvent', 'socialnetwork', '', 'CSocNetLog', 'OnSocNetLogFormatEvent', '', 1),
(331, '2015-04-14 06:30:13', 100, 'photogallery', 'OnAfterUpload', 'socialnetwork', '', 'CSocNetLogTools', 'OnAfterPhotoUpload', '', 1),
(332, '2015-04-14 06:30:13', 100, 'photogallery', 'OnAfterPhotoDrop', 'socialnetwork', '', 'CSocNetLogTools', 'OnAfterPhotoDrop', '', 1),
(333, '2015-04-14 06:30:13', 100, 'photogallery', 'OnBeforeSectionDrop', 'socialnetwork', '', 'CSocNetLogTools', 'OnBeforeSectionDrop', '', 1),
(334, '2015-04-14 06:30:13', 100, 'photogallery', 'OnAfterSectionDrop', 'socialnetwork', '', 'CSocNetLogTools', 'OnAfterSectionDrop', '', 1),
(335, '2015-04-14 06:30:13', 100, 'photogallery', 'OnAfterSectionEdit', 'socialnetwork', '', 'CSocNetLogTools', 'OnAfterSectionEdit', '', 1),
(336, '2015-04-14 06:30:13', 100, 'main', 'OnAuthProvidersBuildList', 'socialnetwork', '', 'CSocNetGroupAuthProvider', 'GetProviders', '', 1),
(337, '2015-04-14 06:30:13', 100, 'im', 'OnBeforeConfirmNotify', 'socialnetwork', '', 'CSocNetUserToGroup', 'OnBeforeConfirmNotify', '', 1),
(338, '2015-04-14 06:30:13', 100, 'im', 'OnBeforeConfirmNotify', 'socialnetwork', '', 'CSocNetUserRelations', 'OnBeforeConfirmNotify', '', 1),
(339, '2015-04-14 06:30:13', 100, 'im', 'OnGetNotifySchema', 'socialnetwork', '', 'CSocNetNotifySchema', 'OnGetNotifySchema', '', 1),
(340, '2015-04-14 06:30:13', 100, 'pull', 'OnGetDependentModule', 'socialnetwork', '', 'CSocNetPullSchema', 'OnGetDependentModule', '', 1),
(341, '2015-04-14 06:30:13', 100, 'main', 'OnUserInitialize', 'socialnetwork', '', 'CSocNetUser', 'OnUserInitialize', '', 1),
(342, '2015-04-14 06:30:13', 100, 'blog', 'OnBlogDelete', 'socialnetwork', '', 'CSocNetLogComments', 'OnBlogDelete', '', 1),
(343, '2015-04-14 06:30:13', 200, 'blog', 'OnBlogDelete', 'socialnetwork', '', 'CSocNetLog', 'OnBlogDelete', '', 1),
(344, '2015-04-14 06:30:13', 100, 'blog', 'OnBlogPostMentionNotifyIm', 'socialnetwork', '', 'CSocNetLogFollow', 'OnBlogPostMentionNotifyIm', '', 1),
(345, '2015-04-14 06:30:13', 100, 'rest', 'OnRestServiceBuildDescription', 'socialnetwork', '', 'CSocNetLogRestService', 'OnRestServiceBuildDescription', '', 1),
(346, '2015-04-14 06:30:13', 100, 'main', 'OnAfterRegisterModule', 'main', '/modules/socialnetwork/install/index.php', 'socialnetwork', 'InstallUserFields', '', 1),
(347, '2015-04-14 06:30:13', 100, 'forum', 'OnAfterCommentAdd', 'socialnetwork', '', 'CSocNetForumComments', 'onAfterCommentAdd', '', 1),
(348, '2015-04-14 06:30:13', 100, 'forum', 'OnAfterCommentUpdate', 'socialnetwork', '', 'CSocNetForumComments', 'OnAfterCommentUpdate', '', 1),
(349, '2015-04-14 06:30:22', 100, 'main', 'OnUserDelete', 'socialservices', '', 'CSocServAuthDB', 'OnUserDelete', '', 1),
(350, '2015-04-14 06:30:22', 100, 'timeman', 'OnAfterTMReportDailyAdd', 'socialservices', '', 'CSocServAuthDB', 'OnAfterTMReportDailyAdd', '', 1),
(351, '2015-04-14 06:30:22', 100, 'timeman', 'OnAfterTMDayStart', 'socialservices', '', 'CSocServAuthDB', 'OnAfterTMDayStart', '', 1),
(352, '2015-04-14 06:30:22', 100, 'timeman', 'OnTimeManShow', 'socialservices', '', 'CSocServEventHandlers', 'OnTimeManShow', '', 1),
(353, '2015-04-14 06:30:22', 100, 'main', 'OnFindExternalUser', 'socialservices', '', 'CSocServAuthDB', 'OnFindExternalUser', '', 1),
(354, '2015-04-14 06:30:25', 100, 'main', 'OnPageStart', 'statistic', '', 'CStopList', 'Check', '', 1),
(355, '2015-04-14 06:30:25', 100, 'main', 'OnBeforeProlog', 'statistic', '', 'CStatistics', 'Keep', '', 1),
(356, '2015-04-14 06:30:25', 100, 'main', 'OnEpilog', 'statistic', '', 'CStatistics', 'Set404', '', 1),
(357, '2015-04-14 06:30:25', 1000, 'main', 'OnBeforeProlog', 'statistic', '', 'CStatistics', 'StartBuffer', '', 1),
(358, '2015-04-14 06:30:25', 10, 'main', 'OnAfterEpilog', 'statistic', '', 'CStatistics', 'EndBuffer', '', 1),
(359, '2015-04-14 06:30:25', 10, 'main', 'OnEventLogGetAuditTypes', 'statistic', '', 'CStatistics', 'GetAuditTypes', '', 1),
(360, '2015-04-14 06:30:25', 100, 'statistic', 'OnCityLookup', 'statistic', '', 'CCityLookup_geoip_mod', 'OnCityLookup', '', 1),
(361, '2015-04-14 06:30:25', 200, 'statistic', 'OnCityLookup', 'statistic', '', 'CCityLookup_geoip_extension', 'OnCityLookup', '', 1),
(362, '2015-04-14 06:30:25', 300, 'statistic', 'OnCityLookup', 'statistic', '', 'CCityLookup_geoip_pure', 'OnCityLookup', '', 1),
(363, '2015-04-14 06:30:25', 400, 'statistic', 'OnCityLookup', 'statistic', '', 'CCityLookup_stat_table', 'OnCityLookup', '', 1),
(364, '2015-04-14 06:30:25', 100, 'cluster', 'OnGetTableList', 'statistic', '', 'statistic', 'OnGetTableList', '', 1),
(365, '2015-04-14 06:30:32', 100, 'main', 'OnPrologAdminTitle', 'storeassist', '', 'CStoreAssist', 'onPrologAdminTitle', '', 1),
(366, '2015-04-14 06:30:32', 100, 'main', 'OnBuildGlobalMenu', 'storeassist', '', 'CStoreAssist', 'onBuildGlobalMenu', '', 1),
(367, '2015-04-14 06:30:33', 100, 'main', 'OnBeforeLangDelete', 'subscribe', '', 'CRubric', 'OnBeforeLangDelete', '', 1),
(368, '2015-04-14 06:30:33', 100, 'main', 'OnUserDelete', 'subscribe', '', 'CSubscription', 'OnUserDelete', '', 1),
(369, '2015-04-14 06:30:33', 100, 'main', 'OnUserLogout', 'subscribe', '', 'CSubscription', 'OnUserLogout', '', 1),
(370, '2015-04-14 06:30:33', 100, 'main', 'OnGroupDelete', 'subscribe', '', 'CPosting', 'OnGroupDelete', '', 1),
(371, '2015-04-14 06:30:35', 100, 'mail', 'OnGetFilterList', 'support', '', 'CSupportEMail', 'OnGetFilterList', '', 1),
(372, '2015-04-14 06:30:36', 100, 'main', 'OnPanelCreate', 'translate', '', 'CTranslateEventHandlers', 'TranslatOnPanelCreate', '', 1),
(373, '2015-04-14 06:30:38', 100, 'main', 'OnBeforeProlog', 'main', '/modules/vote/keepvoting.php', '', '', '', 1),
(374, '2015-04-14 06:30:38', 200, 'main', 'OnUserTypeBuildList', 'vote', '', 'CUserTypeVote', 'GetUserTypeDescription', '', 1),
(375, '2015-04-14 06:30:38', 200, 'main', 'OnUserLogin', 'vote', '', 'CVoteUser', 'OnUserLogin', '', 1),
(376, '2015-04-14 06:30:38', 100, 'im', 'OnGetNotifySchema', 'vote', '', 'CVoteNotifySchema', 'OnGetNotifySchema', '', 1),
(377, '2015-04-14 06:30:40', 200, 'main', 'OnAddRatingVote', 'wiki', '', 'CRatingsComponentsWiki', 'OnAddRatingVote', '', 1),
(378, '2015-04-14 06:30:40', 200, 'main', 'OnCancelRatingVote', 'wiki', '', 'CRatingsComponentsWiki', 'OnCancelRatingVote', '', 1),
(379, '2015-04-14 06:30:40', 100, 'search', 'BeforeIndex', 'wiki', '', 'CRatingsComponentsWiki', 'BeforeIndex', '', 1),
(380, '2015-04-14 06:30:40', 100, 'im', 'OnGetNotifySchema', 'wiki', '', 'CWikiNotifySchema', 'OnGetNotifySchema', '', 1),
(381, '2015-04-14 06:30:42', 200, 'main', 'OnPanelCreate', 'workflow', '', 'CWorkflow', 'OnPanelCreate', '', 1),
(382, '2015-04-14 06:30:42', 100, 'main', 'OnChangeFile', 'workflow', '', 'CWorkflow', 'OnChangeFile', '', 1),
(383, '2015-04-14 06:38:00', 100, 'main', 'OnBeforeProlog', 'main', '/modules/main/install/wizard_sol/panel_button.php', 'CWizardSolPanel', 'ShowPanel', '', 1),
(384, '2015-04-23 07:18:16', 100, 'main', 'OnBuildGlobalMenu', 'omg.import', '', '\\OmgImportEvents', 'OnBuildGlobalMenu', '', 2),
(386, '2015-05-23 05:48:28', 100, 'main', 'OnBuildGlobalMenu', 'itlogic.messages', '', 'CItlogicMessages', 'OnBuildGlobalMenu', '', 1),
(400, '2015-06-09 10:55:19', 0, 'main', 'OnPageStart', 'jivosite.jivosite', '', 'JivoSiteClass', 'addScriptTag', '', 1),
(401, '2015-06-10 08:45:00', 100, 'main', 'OnEpilog', 'main', '', 'CHTMLPagesCache', 'OnEpilog', '', 1),
(402, '2015-06-10 08:45:00', 100, 'main', 'OnLocalRedirect', 'main', '', 'CHTMLPagesCache', 'OnEpilog', '', 1),
(403, '2015-06-10 08:45:00', 100, 'main', 'OnChangeFile', 'main', '', 'CHTMLPagesCache', 'OnChangeFile', '', 1),
(404, '2015-06-10 11:54:11', 100, 'sender', 'OnConnectorList', 'main', '', '\\Bitrix\\Main\\SenderEventHandler', 'onConnectorListUser', '', 1);
INSERT INTO `b_module_to_module` (`ID`, `TIMESTAMP_X`, `SORT`, `FROM_MODULE_ID`, `MESSAGE_ID`, `TO_MODULE_ID`, `TO_PATH`, `TO_CLASS`, `TO_METHOD`, `TO_METHOD_ARG`, `VERSION`) VALUES
(405, '2015-06-10 11:54:16', 100, 'sale', 'OnBasketAdd', 'main', '', '\\Bitrix\\Main\\Analytics\\Catalog', 'catchCatalogBasket', '', 1),
(406, '2015-06-10 11:54:16', 100, 'sale', 'OnOrderSave', 'main', '', '\\Bitrix\\Main\\Analytics\\Catalog', 'catchCatalogOrder', '', 1),
(407, '2015-06-10 11:54:16', 100, 'sale', 'OnSalePayOrder', 'main', '', '\\Bitrix\\Main\\Analytics\\Catalog', 'catchCatalogOrderPayment', '', 1),
(408, '2015-06-10 11:55:33', 100, 'sender', 'OnConnectorList', 'subscribe', '', 'Bitrix\\Subscribe\\SenderEventHandler', 'onConnectorListSubscriber', '', 1),
(409, '2015-06-10 11:55:44', 100, 'sale', 'onBuildCouponProviders', 'catalog', '', '\\Bitrix\\Catalog\\DiscountCouponTable', 'couponManager', '', 2),
(410, '2015-06-10 11:56:16', 100, 'main', 'OnEventLogGetAuditTypes', 'sale', '', 'CSalePaySystemAction', 'OnEventLogGetAuditTypes', '', 1),
(411, '2015-06-10 11:56:22', 100, 'main', 'OnUserLogout', 'sale', '', '\\Bitrix\\Sale\\DiscountCouponsManager', 'logout', '', 1),
(412, '2015-06-10 11:56:26', 100, 'sender', 'OnConnectorList', 'form', '', '\\Bitrix\\Form\\SenderEventHandler', 'onConnectorListForm', '', 1),
(413, '2015-06-10 11:56:34', 100, 'main', 'OnAfterRegisterModule', 'main', '/modules/blog/install/index.php', 'blog', 'installUserFields', '', 1),
(414, '2015-06-10 11:56:58', 100, 'sale', 'OnOrderSave', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onOrderSave', '', 2),
(415, '2015-06-10 11:56:58', 100, 'sale', 'OnBasketOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onBasketOrder', '', 2),
(416, '2015-06-10 11:56:58', 100, 'sale', 'onSalePayOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onSalePayOrder', '', 2),
(417, '2015-06-10 11:56:58', 100, 'sale', 'onSaleDeductOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onSaleDeductOrder', '', 2),
(418, '2015-06-10 11:56:58', 100, 'sale', 'onSaleDeliveryOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onSaleDeliveryOrder', '', 2),
(419, '2015-06-10 11:56:58', 100, 'sale', 'onSaleStatusOrder', 'seo', '', '\\Bitrix\\Seo\\AdvSession', 'onSaleStatusOrder', '', 2),
(420, '2015-06-10 11:57:50', 10, 'iblock', 'OnIBlockPropertyBuildList', 'iblock', '', 'CIBlockProperty', '_Date_GetUserTypeDescription', '', 1),
(422, '2015-06-18 04:47:11', 100, 'main', 'OnBeforeEndBufferContent', 'phpsolutions.backtotop', '', 'CPHPSolutionsBacktotop', 'AddScriptBacktotop', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `b_lang`
--
ALTER TABLE `b_lang`
 ADD PRIMARY KEY (`LID`);

--
-- Indexes for table `b_language`
--
ALTER TABLE `b_language`
 ADD PRIMARY KEY (`LID`);

--
-- Indexes for table `b_lang_domain`
--
ALTER TABLE `b_lang_domain`
 ADD PRIMARY KEY (`LID`,`DOMAIN`);

--
-- Indexes for table `b_ldap_group`
--
ALTER TABLE `b_ldap_group`
 ADD PRIMARY KEY (`LDAP_SERVER_ID`,`GROUP_ID`,`LDAP_GROUP_ID`);

--
-- Indexes for table `b_ldap_server`
--
ALTER TABLE `b_ldap_server`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_learn_answer`
--
ALTER TABLE `b_learn_answer`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_LEARN_ANSWER1` (`QUESTION_ID`);

--
-- Indexes for table `b_learn_attempt`
--
ALTER TABLE `b_learn_attempt`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_LEARN_ATTEMPT1` (`STUDENT_ID`,`TEST_ID`);

--
-- Indexes for table `b_learn_certification`
--
ALTER TABLE `b_learn_certification`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_LEARN_CERTIFICATION1` (`STUDENT_ID`,`COURSE_ID`);

--
-- Indexes for table `b_learn_chapter`
--
ALTER TABLE `b_learn_chapter`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_learn_course`
--
ALTER TABLE `b_learn_course`
 ADD PRIMARY KEY (`ID`), ADD KEY `ix_learn_course_lesson` (`LINKED_LESSON_ID`);

--
-- Indexes for table `b_learn_course_site`
--
ALTER TABLE `b_learn_course_site`
 ADD PRIMARY KEY (`COURSE_ID`,`SITE_ID`);

--
-- Indexes for table `b_learn_gradebook`
--
ALTER TABLE `b_learn_gradebook`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `UX_B_LEARN_GRADEBOOK1` (`STUDENT_ID`,`TEST_ID`);

--
-- Indexes for table `b_learn_groups`
--
ALTER TABLE `b_learn_groups`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_learn_groups_lesson`
--
ALTER TABLE `b_learn_groups_lesson`
 ADD PRIMARY KEY (`LEARNING_GROUP_ID`,`LESSON_ID`), ADD KEY `LESSON_ID` (`LESSON_ID`);

--
-- Indexes for table `b_learn_groups_member`
--
ALTER TABLE `b_learn_groups_member`
 ADD PRIMARY KEY (`LEARNING_GROUP_ID`,`USER_ID`), ADD KEY `USER_ID` (`USER_ID`);

--
-- Indexes for table `b_learn_lesson`
--
ALTER TABLE `b_learn_lesson`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_learn_lesson_edges`
--
ALTER TABLE `b_learn_lesson_edges`
 ADD PRIMARY KEY (`SOURCE_NODE`,`TARGET_NODE`), ADD KEY `TARGET_NODE` (`TARGET_NODE`);

--
-- Indexes for table `b_learn_publish_prohibition`
--
ALTER TABLE `b_learn_publish_prohibition`
 ADD PRIMARY KEY (`COURSE_LESSON_ID`,`PROHIBITED_LESSON_ID`);

--
-- Indexes for table `b_learn_question`
--
ALTER TABLE `b_learn_question`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_LEARN_QUESTION1` (`LESSON_ID`);

--
-- Indexes for table `b_learn_rights`
--
ALTER TABLE `b_learn_rights`
 ADD PRIMARY KEY (`LESSON_ID`,`SUBJECT_ID`);

--
-- Indexes for table `b_learn_rights_all`
--
ALTER TABLE `b_learn_rights_all`
 ADD PRIMARY KEY (`SUBJECT_ID`);

--
-- Indexes for table `b_learn_site_path`
--
ALTER TABLE `b_learn_site_path`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `IX_LEARN_SITE_PATH_2` (`SITE_ID`,`TYPE`);

--
-- Indexes for table `b_learn_student`
--
ALTER TABLE `b_learn_student`
 ADD PRIMARY KEY (`USER_ID`);

--
-- Indexes for table `b_learn_test`
--
ALTER TABLE `b_learn_test`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_LEARN_TEST1` (`COURSE_ID`), ADD KEY `IX_B_LEARN_TEST2` (`PREVIOUS_TEST_ID`);

--
-- Indexes for table `b_learn_test_mark`
--
ALTER TABLE `b_learn_test_mark`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_LEARN_TEST_MARK1` (`TEST_ID`);

--
-- Indexes for table `b_learn_test_result`
--
ALTER TABLE `b_learn_test_result`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_LEARN_TEST_RESULT1` (`ATTEMPT_ID`,`QUESTION_ID`), ADD KEY `IX_B_LEARN_TEST_RESULT2` (`QUESTION_ID`,`ANSWERED`,`CORRECT`);

--
-- Indexes for table `b_lists_field`
--
ALTER TABLE `b_lists_field`
 ADD PRIMARY KEY (`IBLOCK_ID`,`FIELD_ID`);

--
-- Indexes for table `b_lists_permission`
--
ALTER TABLE `b_lists_permission`
 ADD PRIMARY KEY (`IBLOCK_TYPE_ID`,`GROUP_ID`);

--
-- Indexes for table `b_lists_socnet_group`
--
ALTER TABLE `b_lists_socnet_group`
 ADD UNIQUE KEY `ux_b_lists_socnet_group_1` (`IBLOCK_ID`,`SOCNET_ROLE`);

--
-- Indexes for table `b_lists_url`
--
ALTER TABLE `b_lists_url`
 ADD PRIMARY KEY (`IBLOCK_ID`);

--
-- Indexes for table `b_list_rubric`
--
ALTER TABLE `b_list_rubric`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_mail_filter`
--
ALTER TABLE `b_mail_filter`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_MAIL_FILTER_MAILBOX` (`MAILBOX_ID`);

--
-- Indexes for table `b_mail_filter_cond`
--
ALTER TABLE `b_mail_filter_cond`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_mail_log`
--
ALTER TABLE `b_mail_log`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_MAIL_MSGLOG_1` (`MAILBOX_ID`), ADD KEY `IX_MAIL_MSGLOG_2` (`MESSAGE_ID`);

--
-- Indexes for table `b_mail_mailbox`
--
ALTER TABLE `b_mail_mailbox`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_MAIL_MAILBOX_USER_ID` (`USER_ID`);

--
-- Indexes for table `b_mail_mailservices`
--
ALTER TABLE `b_mail_mailservices`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_B_MAIL_MAILSERVICE_ACTIVE` (`ACTIVE`);

--
-- Indexes for table `b_mail_message`
--
ALTER TABLE `b_mail_message`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_MAIL_MESSAGE` (`MAILBOX_ID`);

--
-- Indexes for table `b_mail_message_uid`
--
ALTER TABLE `b_mail_message_uid`
 ADD PRIMARY KEY (`ID`,`MAILBOX_ID`), ADD KEY `IX_MAIL_MSG_UID` (`MAILBOX_ID`);

--
-- Indexes for table `b_mail_msg_attachment`
--
ALTER TABLE `b_mail_msg_attachment`
 ADD PRIMARY KEY (`ID`), ADD KEY `IX_MAIL_MESSATTACHMENT` (`MESSAGE_ID`);

--
-- Indexes for table `b_mail_spam_weight`
--
ALTER TABLE `b_mail_spam_weight`
 ADD PRIMARY KEY (`WORD_ID`), ADD KEY `mail_spam_good` (`GOOD_CNT`), ADD KEY `mail_spam_bad` (`BAD_CNT`);

--
-- Indexes for table `b_medialib_collection`
--
ALTER TABLE `b_medialib_collection`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_medialib_collection_item`
--
ALTER TABLE `b_medialib_collection_item`
 ADD PRIMARY KEY (`ITEM_ID`,`COLLECTION_ID`);

--
-- Indexes for table `b_medialib_item`
--
ALTER TABLE `b_medialib_item`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_medialib_type`
--
ALTER TABLE `b_medialib_type`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_mobileapp_app`
--
ALTER TABLE `b_mobileapp_app`
 ADD PRIMARY KEY (`CODE`);

--
-- Indexes for table `b_mobileapp_config`
--
ALTER TABLE `b_mobileapp_config`
 ADD PRIMARY KEY (`APP_CODE`,`PLATFORM`);

--
-- Indexes for table `b_module`
--
ALTER TABLE `b_module`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `b_module_group`
--
ALTER TABLE `b_module_group`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `UK_GROUP_MODULE` (`MODULE_ID`,`GROUP_ID`,`SITE_ID`);

--
-- Indexes for table `b_module_to_module`
--
ALTER TABLE `b_module_to_module`
 ADD PRIMARY KEY (`ID`), ADD KEY `ix_module_to_module` (`FROM_MODULE_ID`,`MESSAGE_ID`,`TO_MODULE_ID`,`TO_CLASS`,`TO_METHOD`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `b_ldap_server`
--
ALTER TABLE `b_ldap_server`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_answer`
--
ALTER TABLE `b_learn_answer`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_attempt`
--
ALTER TABLE `b_learn_attempt`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_certification`
--
ALTER TABLE `b_learn_certification`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_chapter`
--
ALTER TABLE `b_learn_chapter`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_course`
--
ALTER TABLE `b_learn_course`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_gradebook`
--
ALTER TABLE `b_learn_gradebook`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_groups`
--
ALTER TABLE `b_learn_groups`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_lesson`
--
ALTER TABLE `b_learn_lesson`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_question`
--
ALTER TABLE `b_learn_question`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_site_path`
--
ALTER TABLE `b_learn_site_path`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `b_learn_test`
--
ALTER TABLE `b_learn_test`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_test_mark`
--
ALTER TABLE `b_learn_test_mark`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_learn_test_result`
--
ALTER TABLE `b_learn_test_result`
MODIFY `ID` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_list_rubric`
--
ALTER TABLE `b_list_rubric`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `b_mail_filter`
--
ALTER TABLE `b_mail_filter`
MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_mail_filter_cond`
--
ALTER TABLE `b_mail_filter_cond`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_mail_log`
--
ALTER TABLE `b_mail_log`
MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_mail_mailbox`
--
ALTER TABLE `b_mail_mailbox`
MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `b_mail_mailservices`
--
ALTER TABLE `b_mail_mailservices`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `b_mail_message`
--
ALTER TABLE `b_mail_message`
MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_mail_msg_attachment`
--
ALTER TABLE `b_mail_msg_attachment`
MODIFY `ID` int(18) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `b_medialib_collection`
--
ALTER TABLE `b_medialib_collection`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `b_medialib_item`
--
ALTER TABLE `b_medialib_item`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `b_medialib_type`
--
ALTER TABLE `b_medialib_type`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `b_module_group`
--
ALTER TABLE `b_module_group`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=95;
--
-- AUTO_INCREMENT for table `b_module_to_module`
--
ALTER TABLE `b_module_to_module`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=423;SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
